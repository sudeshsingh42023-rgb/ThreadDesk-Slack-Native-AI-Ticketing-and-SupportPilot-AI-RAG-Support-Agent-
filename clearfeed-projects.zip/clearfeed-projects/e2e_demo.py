"""End-to-end demo wiring both projects together (no network, all external services faked).

  Slack @mention -> SupportPilot proposes "create ticket" -> human clicks Approve -> ThreadDesk creates the ticket
  and a GitHub issue -> GitHub closes the issue (webhook) -> SupportPilot reports the ticket as closed.

Run:  python e2e_demo.py      (needs: pip install -r threaddesk/requirements.txt -r supportpilot/requirements.txt)
"""
import hashlib
import hmac
import json
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import urlencode

ROOT = Path(__file__).parent
sys.path[:0] = [str(ROOT / "threaddesk"), str(ROOT / "supportpilot")]

from fastapi.testclient import TestClient  # noqa: E402

from app.clients import FakeGitHubClient, FakeSlackClient as TDSlack  # noqa: E402  (ThreadDesk)
from app.config import Settings as TDSettings  # noqa: E402
from app.main import create_app as create_threaddesk  # noqa: E402
from supportpilot.config import Settings as SPSettings  # noqa: E402
from supportpilot.embeddings import HashingEmbedder  # noqa: E402
from supportpilot.ingest import ingest_directory  # noqa: E402
from supportpilot.main import create_app as create_supportpilot  # noqa: E402
from supportpilot.slack import FakeSlackClient as SPSlack  # noqa: E402
from supportpilot.store import KnowledgeStore  # noqa: E402
from supportpilot.tools import ThreadDeskClient  # noqa: E402

SP_SECRET, GH_SECRET, WS, REPO = "sp-secret", "gh-secret", "T1", "acme/support"


def slack_sign(body: bytes) -> dict:
    ts = str(int(time.time()))
    sig = "v0=" + hmac.new(SP_SECRET.encode(), f"v0:{ts}:".encode() + body, hashlib.sha256).hexdigest()
    return {"X-Slack-Request-Timestamp": ts, "X-Slack-Signature": sig}


def main() -> None:
    tmp = tempfile.mkdtemp()
    td_slack, gh = TDSlack(), FakeGitHubClient()
    td_app = create_threaddesk(
        TDSettings(database_url=f"sqlite:///{tmp}/td.db", github_webhook_secret=GH_SECRET, default_github_repo=REPO,
                   api_key="td-key", worker_enabled=False),
        slack=td_slack, github=gh,
    )
    with TestClient(td_app, headers={"X-API-Key": "td-key"}) as td_http:
        store = KnowledgeStore(":memory:")
        ingest_directory(store, HashingEmbedder(), WS, ROOT / "supportpilot" / "eval" / "kb")
        sp_slack = SPSlack()
        sp_app = create_supportpilot(
            SPSettings(api_key="sp-key", slack_signing_secret=SP_SECRET), store=store, slack=sp_slack,
            threaddesk=ThreadDeskClient("http://testserver", "td-key", client=td_http),
        )
        with TestClient(sp_app) as sp_http:
            def say(text, event_id):
                body = json.dumps({"type": "event_callback", "team_id": WS, "event_id": event_id, "event": {
                    "type": "app_mention", "user": "U1", "text": f"<@UBOT> {text}", "channel": "C1", "ts": "1.1"}}).encode()
                sp_http.post("/slack/events", content=body, headers={**slack_sign(body), "Content-Type": "application/json"})
                return sp_slack.messages[-1]

            print("1) Question the bot can answer:")
            print("   ", say("How many API keys can a workspace have?", "E1")["text"].splitlines()[0])

            print("2) Question it cannot answer -> hands off instead of guessing:")
            print("   ", say("Who is the CEO of Northwind Cloud?", "E2")["text"])

            print("3) Action request -> waits for human approval:")
            msg = say("create a ticket: Export button crashes with a 500 error", "E3")
            print("   ", msg["text"])
            action_id = msg["blocks"][1]["elements"][0]["value"]

            print("4) Human clicks Approve -> SupportPilot calls ThreadDesk:")
            payload = {"type": "block_actions", "team": {"id": WS}, "user": {"id": "U2"}, "channel": {"id": "C1"},
                       "message": {"ts": "1.1"}, "actions": [{"action_id": "approve_action", "value": action_id}]}
            body = urlencode({"payload": json.dumps(payload)}).encode()
            sp_http.post("/slack/interactions", content=body, headers={**slack_sign(body), "Content-Type": "application/x-www-form-urlencoded"})
            print("   ", sp_slack.messages[-1]["text"])

            print("5) ThreadDesk worker syncs the ticket to GitHub:")
            td_app.state.worker.run_once()
            print("   ", {k: (v["title"], v["labels"]) for k, v in gh.issues.items()})

            print("6) Engineer closes the GitHub issue (signed webhook):")
            hook = json.dumps({"action": "closed", "repository": {"full_name": REPO}, "issue": {"number": 1}, "sender": {"login": "dev"}}).encode()
            sig = "sha256=" + hmac.new(GH_SECRET.encode(), hook, hashlib.sha256).hexdigest()
            r = td_http.post("/github/webhook", content=hook, headers={"X-GitHub-Event": "issues", "X-GitHub-Delivery": "d1",
                                                                         "X-Hub-Signature-256": sig, "Content-Type": "application/json"})
            print("   ", r.json())

            print("7) Ask SupportPilot for the ticket status:")
            print("   ", say("what is the status of ticket #1?", "E4")["text"])


if __name__ == "__main__":
    main()
