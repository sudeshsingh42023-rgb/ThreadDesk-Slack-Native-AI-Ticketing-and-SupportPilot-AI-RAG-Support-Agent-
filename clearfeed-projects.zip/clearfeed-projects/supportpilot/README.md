# SupportPilot

A Slack support agent that answers from your docs **with citations**, **hands off to a human instead of guessing**, and
can take actions (open a ticket in [ThreadDesk](../threaddesk)) only after a person approves them.

## What it does

- **Hybrid retrieval**: BM25 + vector similarity fused with reciprocal rank fusion (`bm25`, `vector`, `hybrid` modes). Heading-aware chunking with overlap.
- **Grounded answers**: the LLM sees only retrieved passages in `<source>` tags and must cite them as `[n]`. Answers with no valid citation are rejected.
- **Confidence gate**: if the retrieved passages do not cover the question's rare terms (idf²-weighted), the bot hands off and points at the closest docs instead of answering. LLM outage also degrades to a handoff.
- **Prompt-injection defenses**: passages that look like instructions to the model are dropped and flagged; URLs and e-mail addresses in an answer that are not in the cited passages are stripped.
- **Approval-gated actions**: read-only tools (ticket status) run immediately; write tools (create ticket) are stored as *pending* and run only when a human clicks Approve in Slack. Arguments are schema-validated at proposal and again at execution, an atomic status claim prevents double execution, an optional approver allowlist limits who may approve, per-workspace tool policy limits which tools exist, and every step lands in an audit table.
- **Multi-tenant**: chunks, actions and audit rows carry `workspace_id`; every query is scoped by it.
- **Evaluation harness** (`eval/`): labeled questions, retrieval hit@k, answer correctness with citation check, deflection rate, false-answer rate on unanswerable questions, and cross-validated threshold tuning.

## Run it

```bash
pip install -r requirements.txt
python -m supportpilot.ingest eval/kb --workspace T123       # index a folder of .md/.txt files
uvicorn supportpilot.main:create_app --factory --port 8001   # needs .env (see .env.example)
pytest -q                                                     # 35 tests, no network
python -m eval.run_eval                                       # regenerate eval/results.md
python ../e2e_demo.py                                         # SupportPilot + ThreadDesk end to end
```

Slack: Event Subscriptions → `/slack/events` (`app_mention`); Interactivity → `/slack/interactions`.
Without `ANTHROPIC_API_KEY` the app uses the offline `ExtractiveLLM` (returns the best-matching sentences with citations).

## Evaluation: what the numbers do and do not say

Dataset: 39 answerable + 13 unanswerable hand-written questions over a 10-document sample knowledge base (`eval/kb`).
Answerable questions are scored correct only if the answer contains the expected facts **and** cites the expected document.
Answerer under test: the offline `ExtractiveLLM` (deterministic, no API key).

At the default threshold (0.30), over all 52 questions (in-sample): **hit@3 100%**, **82% of answerable questions resolved
correctly (precision 86%)**, **0 of 13 unanswerable questions answered**. Answering everything with no gate gets 34/39 right.

Cross-validated (tune the threshold on one half, evaluate on the other, then swap; see `eval/results.md`):

| fold | threshold chosen | deflection | precision | false-answer |
|---|---|---|---|---|
| tune A, eval B | 0.80 | 58% | 100% | 0% |
| tune B, eval A | 0.30 | 75% | 79% | 0% |

Read these honestly:

1. **The gate catches unanswerable questions but not wrong sentence picks.** False-answer is 0% in every fold, but the confidence
   score measures whether the retrieved text covers the question's terms, not whether the right sentence was chosen inside it,
   so a few wrong answers get high confidence. This is why the two folds pick different thresholds. A stronger answerer plus a
   faithfulness check is the next step.
2. **Retrieval modes tie on this set.** `bm25`, `vector` and `hybrid` give the same answer decisions, and chunk size (60/120/250 words) made no difference.
   The default embedder is a *hashing* embedder: it hashes word and bigram features, it is not a semantic model, so the vector side adds little
   beyond BM25 here. Implement the `Embedder` protocol with a real embedding model before claiming a hybrid gain.
3. **Small and hand-written.** I changed the answerer and confidence formula while looking at failures on both halves, and fixed one mislabeled question,
   so these numbers are optimistic. Use the harness as a regression signal on your own docs and questions, not as a benchmark.

## Known limitations

- Vector store is SQLite with in-memory search (fine for thousands of chunks). There is no pgvector adapter yet; add one behind `KnowledgeStore`/`Retriever` for larger corpora.
- Intent routing for actions is regex-based, not LLM tool-calling.
- The Anthropic call and the ThreadDesk client are tested against mocked HTTP only; Slack and GitHub were never exercised live.
- The hand-off message is posted in the thread; a production setup should route it to a responders' channel.
