# API keys

## Creating a key
Go to Settings > Developer > API Keys and choose Create key. Each key has a scope: read, write, or admin. The secret is shown only once, so copy it immediately. A workspace can have at most 10 active keys.

## Rotating a key
To rotate a key, open Settings > Developer > API Keys, select the key, and choose Rotate. The old key keeps working for a 24 hour grace period so you can deploy the new one without downtime. After 24 hours the old key stops working.

## Leaked keys
If a key is exposed, revoke it immediately from the same page. Revoked keys stop working within 60 seconds. Check the audit log to see which requests used the key.
