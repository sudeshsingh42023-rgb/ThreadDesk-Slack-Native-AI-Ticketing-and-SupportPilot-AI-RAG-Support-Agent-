# Billing and plans

## Plans and prices
Northwind Cloud has three plans. Free costs nothing. Pro costs $12 per user per month. Business costs $29 per user per month. Annual billing gives two months free.

## Invoices
Invoices are available under Settings > Billing > Invoices. They are emailed to the billing contact on the first day of each billing cycle.

## Failed payments
If a card payment fails, we retry 3 times over 7 days. The workspace stays fully active during retries. If all retries fail the workspace is downgraded to the Free plan.

## Changing plans
You can upgrade at any time and the charge is prorated for the rest of the cycle. Downgrades take effect at the end of the current billing cycle.

## Refunds
Annual plans can be refunded within 14 days of purchase. Monthly plans are not refundable, but you can cancel at any time.
