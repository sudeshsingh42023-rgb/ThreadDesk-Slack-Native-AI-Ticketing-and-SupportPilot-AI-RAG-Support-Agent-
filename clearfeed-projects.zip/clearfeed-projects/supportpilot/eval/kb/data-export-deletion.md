# Data export and deletion

## Exporting your data
Go to Settings > Data > Export. The export is a zip file. For workspaces under 50 GB you receive an email with the download link within 1 hour. The link is valid for 7 days.

## Trash
Deleted files stay in the trash for 30 days on Free and 90 days on Pro and Business. Files can be restored from the trash during that time.

## Deleting your account
Account deletion has a 30 day grace period. During the grace period you can cancel the deletion by signing in. After 30 days all data is permanently erased.
