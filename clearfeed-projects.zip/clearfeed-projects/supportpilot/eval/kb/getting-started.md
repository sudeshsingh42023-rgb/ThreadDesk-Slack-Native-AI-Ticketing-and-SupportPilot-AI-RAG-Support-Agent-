# Getting started

## Create your account
Sign up at the Northwind Cloud website with a work email. You will receive a verification link that expires after 24 hours. After verifying, you land in your first workspace.

## Install the CLI
Install the command line tool with `npm install -g @northwind/cli`, then run `nw login`. The CLI requires Node.js 18 or newer. Run `nw whoami` to confirm you are logged in.

## Free tier
Every new workspace starts on the Free plan. Free includes 5 GB of storage, 3 members, and 100 API requests per minute.
