# Integrations

## Slack
Install the Northwind app from Settings > Integrations > Slack. Choose which channels receive notifications for new files and shares.

## Zapier
The Northwind Zapier app supports the triggers New File and New Share, and the action Upload File.

## GitHub Actions
Use the northwind/upload-action in your workflow to upload build artifacts. Store your API key as a repository secret and give it the write scope.
