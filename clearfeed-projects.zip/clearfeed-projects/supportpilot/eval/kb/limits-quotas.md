# Limits and quotas

## API rate limits
Free allows 100 requests per minute. Pro allows 600 requests per minute. Business allows 3000 requests per minute. When you exceed the limit the API returns HTTP 429 with a Retry-After header telling you how many seconds to wait.

## Storage
Free includes 5 GB per workspace. Pro includes 1 TB per workspace. Business includes 10 TB per workspace.

## File size
The maximum size of a single file is 5 GB. Files larger than 100 MB should be uploaded with multipart upload.

## Members
Free supports up to 3 members. Pro and Business support unlimited members.
