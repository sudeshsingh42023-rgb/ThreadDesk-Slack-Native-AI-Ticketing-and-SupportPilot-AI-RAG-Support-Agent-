# Security

## Authentication
Two-factor authentication using an authenticator app (TOTP) is available on all plans. Single sign-on with SAML is available on the Business plan only.

## Encryption
Data is encrypted at rest with AES-256 and in transit with TLS 1.2 or newer.

## Audit logs
Audit logs record logins, key usage, sharing changes, and member changes. Pro keeps audit logs for 90 days. Business keeps them for 1 year.

## Compliance
Northwind Cloud has completed a SOC 2 Type II audit. The report is available to Business customers under NDA.
