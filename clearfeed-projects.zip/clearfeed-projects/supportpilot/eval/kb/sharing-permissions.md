# Sharing and permissions

## Roles
There are three roles: Viewer can read files, Editor can read and change files, and Owner can also manage members and billing.

## Share links
Share links expire after 7 days by default. You can set the expiry to any value up to 90 days. Password-protected links are available on Pro and Business.

## Transferring ownership
An Owner can transfer ownership from Settings > Members by choosing Make owner next to another member. A workspace must always have at least one Owner.

## Removing members
When a member is removed, their files stay in the workspace and remain available to the other members.
