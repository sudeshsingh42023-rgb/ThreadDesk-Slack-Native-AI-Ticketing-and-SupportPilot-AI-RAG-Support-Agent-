# Troubleshooting

## Upload fails with 413
A 413 error means the file is larger than the 5 GB limit, or the request body was too big for a single upload. Use multipart upload for large files, and split anything above 5 GB.

## Error 401 invalid_token
The key was revoked, has expired, or was rotated more than 24 hours ago. Create or rotate a key and update your configuration.

## Error 403 insufficient_scope
The key does not have the scope needed for this call. A read key cannot write. Create a key with the write or admin scope.

## Sync is stuck
If the desktop sync client stops progressing, quit the app and run `nw sync --reset` from the CLI, then start the app again. Your files are not deleted by a reset.

## quota_exceeded
This error means the workspace is out of storage. Delete files and empty the trash, or upgrade the plan.
