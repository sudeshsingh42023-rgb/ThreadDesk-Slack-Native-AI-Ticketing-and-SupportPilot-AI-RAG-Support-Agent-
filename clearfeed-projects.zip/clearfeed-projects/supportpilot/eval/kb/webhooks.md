# Webhooks

## Events
Webhooks can notify your server about file.created, file.deleted, and share.created events. A workspace can register up to 20 webhook endpoints.

## Verifying signatures
Every delivery includes an X-Northwind-Signature header containing an HMAC-SHA256 signature of the raw request body, computed with your endpoint secret. Always verify the signature before trusting a payload.

## Delivery and retries
Your endpoint must respond with a 2xx status within 10 seconds. If it does not, we retry up to 5 times with exponential backoff, for up to 1 hour. Endpoints that fail continuously for 3 days are disabled automatically.
