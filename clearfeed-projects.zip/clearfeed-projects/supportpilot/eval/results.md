Dataset: 39 answerable + 13 unanswerable questions over 10 docs.

| retrieval | chunk words | fold | threshold | hit@1 | hit@3 | deflection | precision | false-answer |
|---|---|---|---|---|---|---|---|---|
| bm25 | 120 | tune A, eval B | 0.80 | 95% | 100% | 58% | 100% | 0% |
| bm25 | 120 | tune B, eval A | 0.30 | 90% | 100% | 75% | 79% | 0% |
| vector | 120 | tune A, eval B | 0.80 | 89% | 100% | 58% | 100% | 0% |
| vector | 120 | tune B, eval A | 0.30 | 90% | 100% | 75% | 79% | 0% |
| hybrid | 120 | tune A, eval B | 0.80 | 95% | 100% | 58% | 100% | 0% |
| hybrid | 120 | tune B, eval A | 0.30 | 90% | 100% | 75% | 79% | 0% |
| hybrid | 60 | tune A, eval B | 0.80 | 95% | 100% | 58% | 100% | 0% |
| hybrid | 60 | tune B, eval A | 0.30 | 90% | 100% | 75% | 79% | 0% |
| hybrid | 250 | tune A, eval B | 0.80 | 95% | 100% | 58% | 100% | 0% |
| hybrid | 250 | tune B, eval A | 0.30 | 90% | 100% | 75% | 79% | 0% |
