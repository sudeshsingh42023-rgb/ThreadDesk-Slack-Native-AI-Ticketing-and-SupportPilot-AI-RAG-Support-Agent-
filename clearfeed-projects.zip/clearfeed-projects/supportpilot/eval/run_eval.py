"""Evaluation harness.  Run from the project root:  python -m eval.run_eval

For each retrieval/chunking configuration it:
  1. indexes eval/kb, 2. answers every labeled question with the offline ExtractiveLLM (reproducible, no API key),
  3. picks the confidence threshold with the best utility on one half of the questions (+1 correct answer,
     -2 wrong or unwarranted answer, 0 handoff),
  4. reports metrics on the OTHER half, then swaps the halves (2-fold cross-validation), so no number is measured
     on questions that were used to choose the threshold.

Halves A and B are assigned by alternating position within the answerable and unanswerable groups, so each half
mixes topics. The knowledge base and dataset are small and hand-written: treat the numbers as a regression
signal for retrieval changes, not as a claim about production accuracy.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from supportpilot.agent import SupportAgent
from supportpilot.embeddings import HashingEmbedder
from supportpilot.ingest import ingest_directory
from supportpilot.llm import ExtractiveLLM
from supportpilot.retriever import Retriever
from supportpilot.store import KnowledgeStore
from supportpilot.tools import ActionManager

HERE = Path(__file__).parent
WS = "eval"


@dataclass
class Row:
    q: dict
    hit1: bool
    hit3: bool
    action: str  # answer | handoff (with threshold 0)
    confidence: float
    correct: bool  # answer text contains all must_include AND cites the expected source


def load_dataset() -> list[dict]:
    rows = [json.loads(l) for l in (HERE / "dataset.jsonl").read_text().splitlines() if l.strip()]
    answerable = [r for r in rows if r["answerable"]]
    unanswerable = [r for r in rows if not r["answerable"]]
    # interleave so that dev/test alternate within each group
    for group in (answerable, unanswerable):
        for i, r in enumerate(group):
            r["split"] = "dev" if i % 2 == 0 else "test"
    return rows


def run_config(mode: str, max_words: int, overlap: int = 15, rows: list[dict] | None = None) -> list[Row]:
    store, emb = KnowledgeStore(":memory:"), HashingEmbedder()
    ingest_directory(store, emb, WS, HERE / "kb", max_words, overlap)
    retriever = Retriever(store, emb, mode)
    agent = SupportAgent(retriever, ExtractiveLLM(), store, ActionManager(store, {}, datetime.utcnow), datetime.utcnow, threshold=0.0)
    out = []
    for q in rows or load_dataset():
        hits = retriever.search(WS, q["question"], 3)
        srcs = [h.chunk.source for h in hits]
        res = agent._answer(WS, q["question"], "eval")
        correct = False
        if q["answerable"] and res.action == "answer":
            text = res.text.lower()
            correct = all(m in text for m in q["must_include"]) and any(c["source"] == q["source"] for c in res.citations)
        out.append(Row(q, bool(srcs) and srcs[0] == q.get("source"), q.get("source") in srcs, res.action, res.confidence, correct))
    return out


def decide(r: Row, thr: float) -> bool:
    """Would the bot answer (rather than hand off) at this threshold?"""
    return r.action == "answer" and r.confidence >= thr


def metrics(rows: list[Row], thr: float) -> dict:
    ans = [r for r in rows if r.q["answerable"]]
    una = [r for r in rows if not r.q["answerable"]]
    answered = [r for r in ans if decide(r, thr)]
    correct = [r for r in answered if r.correct]
    return {
        "hit@1": sum(r.hit1 for r in ans) / len(ans),
        "hit@3": sum(r.hit3 for r in ans) / len(ans),
        "deflection": len(correct) / len(ans),  # answerable questions resolved correctly without a human
        "precision": (len(correct) / len(answered)) if answered else 0.0,  # of the answers given, how many were right
        "false_answer": sum(decide(r, thr) for r in una) / len(una),  # unanswerable questions the bot answered anyway
    }


WRONG_ANSWER_COST = 2.0  # product choice: a wrong answer in a customer channel is worse than a handoff


def utility(rows: list[Row], thr: float) -> float:
    """+1 per correct answer, -WRONG_ANSWER_COST per wrong answer (incl. answering an unanswerable question),
    0 per handoff."""
    total = 0.0
    for r in rows:
        if not decide(r, thr):
            continue
        total += 1.0 if (r.q["answerable"] and r.correct) else -WRONG_ANSWER_COST
    return total


def tune_threshold(dev: list[Row]) -> float:
    """Pick the threshold with the best utility on the tuning half (ties go to the lowest threshold)."""
    best_thr, best = 0.0, float("-inf")
    for thr in [x / 100 for x in range(0, 101, 5)]:
        u = utility(dev, thr)
        if u > best:
            best_thr, best = thr, u
    return best_thr


def fmt(x: float) -> str:
    return f"{x * 100:.0f}%"


def main() -> None:
    dataset = load_dataset()
    configs = [("bm25", 120), ("vector", 120), ("hybrid", 120), ("hybrid", 60), ("hybrid", 250)]
    lines = [
        "| retrieval | chunk words | fold | threshold | hit@1 | hit@3 | deflection | precision | false-answer |",
        "|---|---|---|---|---|---|---|---|---|",
    ]
    for mode, words in configs:
        rows = run_config(mode, words, rows=dataset)
        a = [r for r in rows if r.q["split"] == "dev"]
        b = [r for r in rows if r.q["split"] == "test"]
        for label, tune_on, eval_on in (("tune A, eval B", a, b), ("tune B, eval A", b, a)):
            thr = tune_threshold(tune_on)
            m = metrics(eval_on, thr)
            lines.append(
                f"| {mode} | {words} | {label} | {thr:.2f} | {fmt(m['hit@1'])} | {fmt(m['hit@3'])} | "
                f"{fmt(m['deflection'])} | {fmt(m['precision'])} | {fmt(m['false_answer'])} |"
            )
    n_a = sum(r["answerable"] for r in dataset)
    header = f"Dataset: {n_a} answerable + {len(dataset) - n_a} unanswerable questions over {len(list((HERE / 'kb').glob('*.md')))} docs.\n\n"
    table = header + "\n".join(lines)
    print(table)
    (HERE / "results.md").write_text(table + "\n")


if __name__ == "__main__":
    main()
