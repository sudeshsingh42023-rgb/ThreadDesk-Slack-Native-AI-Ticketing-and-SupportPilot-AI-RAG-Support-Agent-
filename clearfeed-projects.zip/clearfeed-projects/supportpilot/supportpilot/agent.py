from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable

from .llm import INSUFFICIENT, LLM, ExtractiveLLM, Passage
from .retriever import Hit, Retriever
from .safety import looks_like_injection, validate_answer
from .store import KnowledgeStore
from .textutil import tokens
from .tools import ActionManager, ToolContext

CREATE_RE = re.compile(r"\b(create|open|file|raise|log)\b.{0,25}\b(ticket|issue)\b", re.I)
STATUS_RE = re.compile(r"(?:status|state)\b.{0,30}?ticket\s*#?(\d+)|ticket\s*#?(\d+)\s*(?:status|state)", re.I)


@dataclass
class AgentResult:
    action: str  # answer | handoff | proposal | tool_result | refused
    text: str
    confidence: float = 0.0
    citations: list[dict] = field(default_factory=list)
    reason: str = ""
    flagged: list[str] = field(default_factory=list)
    draft: str = ""
    related: list[str] = field(default_factory=list)
    action_id: int | None = None


class SupportAgent:
    def __init__(
        self,
        retriever: Retriever,
        llm: LLM,
        store: KnowledgeStore,
        actions: ActionManager,
        clock: Callable[[], datetime],
        threshold: float = 0.55,
        top_k: int = 4,
    ):
        self.retriever, self.llm, self.store, self.actions, self.clock = retriever, llm, store, actions, clock
        self.threshold, self.top_k = threshold, top_k
        self._fallback = ExtractiveLLM()

    # ---- confidence --------------------------------------------------------------------------------------
    def confidence(self, workspace_id: str, question: str, hits: list[Hit]) -> float:
        """idf-squared-weighted share of the question's terms found in the best of the top-3 passages.
        Common words (e.g. the product name) carry almost no idf weight, so off-topic questions score low."""
        if not hits:
            return 0.0
        bm25 = self.retriever.index(workspace_id).bm25
        q = set(tokens(question))
        if not q:
            return 0.0
        total = sum(bm25.idf(t) ** 2 for t in q)
        best = 0.0
        for h in hits[:3]:
            have = set(tokens(f"{h.chunk.heading} {h.chunk.text}"))
            best = max(best, sum(bm25.idf(t) ** 2 for t in q & have) / total)
        return round(best, 3)

    # ---- main entrypoint ---------------------------------------------------------------------------------
    def ask(self, workspace_id: str, question: str, user_id: str = "", channel_id: str = "", thread_ts: str | None = None) -> AgentResult:
        ctx = ToolContext(workspace_id, channel_id, user_id)
        m = STATUS_RE.search(question)
        if m:
            tid = int(m.group(1) or m.group(2))
            out = self.actions.propose("ticket_status", {"ticket_id": tid}, ctx)
            return AgentResult("tool_result", out.message)
        if CREATE_RE.search(question):
            title = question.split(":", 1)[1].strip() if ":" in question else question.strip()
            out = self.actions.propose("create_ticket", {"title": title[:200], "body": f"Requested via SupportPilot by {user_id or 'unknown'}"}, ctx, thread_ts)
            if not out.ok:
                return AgentResult("refused", out.message)
            return AgentResult("proposal", out.message, action_id=out.action_id)
        return self._answer(workspace_id, question, user_id)

    def _answer(self, workspace_id: str, question: str, user_id: str) -> AgentResult:
        hits = self.retriever.search(workspace_id, question, self.top_k)
        flagged = [f"{h.chunk.source}#{h.chunk.id}" for h in hits if looks_like_injection(h.chunk.text)]
        safe_hits = [h for h in hits if f"{h.chunk.source}#{h.chunk.id}" not in flagged]
        conf = self.confidence(workspace_id, question, safe_hits)
        idf = self.retriever.index(workspace_id).bm25.idf if safe_hits else None
        passages = [Passage(i + 1, h.chunk.source, h.chunk.heading, h.chunk.text) for i, h in enumerate(safe_hits)]

        def handoff(reason: str) -> AgentResult:
            draft = ""
            if reason == "llm_error" and passages:  # degraded mode: extractive draft for the human to review
                draft = self._fallback.generate(question, passages, idf)
                draft = "" if draft == INSUFFICIENT else draft
            related = list(dict.fromkeys(f"{h.chunk.source} > {h.chunk.heading}" for h in safe_hits[:2]))
            self._log(workspace_id, user_id, "handoff", reason, conf, flagged)
            return AgentResult(
                "handoff",
                "I'm not confident I can answer this accurately, so I've flagged it for a teammate.",
                conf, reason=reason, flagged=flagged, draft=draft, related=related,
            )

        if conf < self.threshold:
            return handoff("low_confidence")
        try:
            raw = self.llm.generate(question, passages, idf)
        except Exception:  # noqa: BLE001 - LLM outage must degrade to a human, not an error
            return handoff("llm_error")
        if raw.strip().startswith(INSUFFICIENT):
            return handoff("model_insufficient_context")

        v = validate_answer(raw, {p.n: p.text for p in passages})
        if not v.ok:
            return handoff(v.reason)
        cites = [{"n": n, "source": passages[n - 1].source, "section": passages[n - 1].heading} for n in v.citations]
        self._log(workspace_id, user_id, "answer", f"cites={[c['source'] for c in cites]} removed={v.removed}", conf, flagged)
        return AgentResult("answer", v.text, conf, cites, flagged=flagged)

    def _log(self, ws: str, user: str, event: str, detail: str, conf: float, flagged: list[str]) -> None:
        self.store.audit(self.clock().isoformat(), ws, user or "api", event, f"{detail} conf={conf} flagged={flagged}")
