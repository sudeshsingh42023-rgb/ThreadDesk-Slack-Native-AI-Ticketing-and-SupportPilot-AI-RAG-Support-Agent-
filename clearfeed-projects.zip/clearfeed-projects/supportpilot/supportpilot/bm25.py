from __future__ import annotations

import math
from collections import Counter

from .textutil import tokens


class BM25:
    def __init__(self, docs: list[str], k1: float = 1.5, b: float = 0.75):
        self.k1, self.b = k1, b
        self.doc_tokens = [tokens(d) for d in docs]
        self.doc_len = [len(t) for t in self.doc_tokens]
        self.avgdl = (sum(self.doc_len) / len(docs)) if docs else 0.0
        self.tf = [Counter(t) for t in self.doc_tokens]
        df: Counter = Counter()
        for t in self.tf:
            df.update(t.keys())
        n = len(docs)
        self.n = n
        self._idf = {w: math.log(1 + (n - d + 0.5) / (d + 0.5)) for w, d in df.items()}

    def idf(self, token: str) -> float:
        """Unseen tokens get the max idf (they are maximally informative but match nothing)."""
        return self._idf.get(token, math.log(1 + (self.n + 0.5) / 0.5))

    def scores(self, query: str) -> list[float]:
        q = set(tokens(query))
        out = []
        for tf, dl in zip(self.tf, self.doc_len):
            s = 0.0
            for w in q:
                f = tf.get(w, 0)
                if f:
                    s += self._idf[w] * f * (self.k1 + 1) / (f + self.k1 * (1 - self.b + self.b * dl / (self.avgdl or 1)))
            out.append(s)
        return out
