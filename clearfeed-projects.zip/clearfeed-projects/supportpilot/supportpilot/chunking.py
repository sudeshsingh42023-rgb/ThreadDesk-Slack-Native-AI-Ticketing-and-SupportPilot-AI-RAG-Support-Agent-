from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Chunk:
    source: str
    heading: str
    text: str
    idx: int = 0


def chunk_markdown(text: str, source: str, max_words: int = 120, overlap: int = 15) -> list[Chunk]:
    """Heading-aware chunking: split on markdown headings, then pack paragraphs up to max_words,
    carrying `overlap` words of context into the next chunk of the same section."""
    sections: list[tuple[str, list[str]]] = []
    heading, buf = source, []
    for line in text.splitlines():
        if line.startswith("#"):
            if any(l.strip() for l in buf):
                sections.append((heading, buf))
            heading, buf = line.lstrip("#").strip() or source, []
        else:
            buf.append(line)
    if any(l.strip() for l in buf):
        sections.append((heading, buf))

    chunks: list[Chunk] = []
    for heading, lines in sections:
        paragraphs = [p.strip() for p in "\n".join(lines).split("\n\n") if p.strip()]
        current: list[str] = []
        count = 0
        for para in paragraphs:
            n = len(para.split())
            if current and count + n > max_words:
                chunks.append(Chunk(source, heading, "\n\n".join(current)))
                tail = " ".join("\n\n".join(current).split()[-overlap:]) if overlap else ""
                current, count = ([tail] if tail else []), len(tail.split())
            current.append(para)
            count += n
        if current:
            chunks.append(Chunk(source, heading, "\n\n".join(current)))
    for i, c in enumerate(chunks):
        c.idx = i
    return chunks
