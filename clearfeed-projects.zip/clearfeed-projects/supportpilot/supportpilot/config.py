from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    db_path: str = "supportpilot.db"
    api_key: str = "dev-api-key"
    slack_signing_secret: str = "dev-signing-secret"
    slack_bot_token: str = ""
    anthropic_api_key: str = ""
    llm_model: str = "claude-sonnet-4-6"
    threaddesk_url: str = "http://localhost:8000"
    threaddesk_api_key: str = "dev-api-key"
    confidence_threshold: float = 0.30  # tuned on the sample KB via eval/run_eval.py; re-tune for your own docs
    retrieval_mode: str = "hybrid"  # bm25 | vector | hybrid
    top_k: int = 4
    approver_ids: str = ""  # comma-separated Slack user ids allowed to approve actions; empty = any user
    slack_timestamp_tolerance_s: int = 300
