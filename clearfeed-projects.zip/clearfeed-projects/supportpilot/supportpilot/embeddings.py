"""Embedder interface plus a dependency-free baseline.

HashingEmbedder is NOT a semantic model: it hashes unigrams and bigrams into a fixed-size vector
(feature hashing, signed, sublinear tf). It makes the pipeline runnable offline and deterministic. Swap in a real
embedding model by implementing `embed(texts) -> ndarray` (rows L2-normalised).
"""
from __future__ import annotations

import zlib
from typing import Protocol

import numpy as np

from .textutil import tokens


class Embedder(Protocol):
    dim: int

    def embed(self, texts: list[str]) -> np.ndarray: ...


class HashingEmbedder:
    def __init__(self, dim: int = 1024):
        self.dim = dim

    def _vec(self, text: str) -> np.ndarray:
        toks = tokens(text)
        feats = toks + [f"{a}_{b}" for a, b in zip(toks, toks[1:])]
        v = np.zeros(self.dim, dtype=np.float32)
        for f in feats:
            h = zlib.crc32(f.encode())
            v[h % self.dim] += 1.0 if (h >> 31) & 1 else -1.0
        v = np.sign(v) * np.log1p(np.abs(v))
        n = np.linalg.norm(v)
        return v / n if n else v

    def embed(self, texts: list[str]) -> np.ndarray:
        return np.vstack([self._vec(t) for t in texts]) if texts else np.zeros((0, self.dim), dtype=np.float32)
