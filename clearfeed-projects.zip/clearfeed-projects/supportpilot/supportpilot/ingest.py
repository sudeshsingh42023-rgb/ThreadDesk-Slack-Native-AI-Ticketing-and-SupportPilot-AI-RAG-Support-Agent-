"""Index a folder of .md/.txt files:  python -m supportpilot.ingest ./docs --workspace T123"""
from __future__ import annotations

import argparse
from pathlib import Path

from .chunking import chunk_markdown
from .config import Settings
from .embeddings import Embedder, HashingEmbedder
from .store import KnowledgeStore


def ingest_directory(store: KnowledgeStore, embedder: Embedder, workspace_id: str, folder: Path, max_words: int = 120, overlap: int = 15) -> int:
    total = 0
    for path in sorted(folder.rglob("*")):
        if path.suffix.lower() not in {".md", ".txt"}:
            continue
        chunks = chunk_markdown(path.read_text(encoding="utf-8"), path.name, max_words, overlap)
        store.replace_source(workspace_id, path.name, chunks, embedder.embed([f"{c.heading}\n{c.text}" for c in chunks]))
        total += len(chunks)
    return total


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("folder", type=Path)
    ap.add_argument("--workspace", required=True)
    ap.add_argument("--max-words", type=int, default=120)
    args = ap.parse_args()
    n = ingest_directory(KnowledgeStore(Settings().db_path), HashingEmbedder(), args.workspace, args.folder, args.max_words)
    print(f"indexed {n} chunks into workspace {args.workspace}")


if __name__ == "__main__":
    main()
