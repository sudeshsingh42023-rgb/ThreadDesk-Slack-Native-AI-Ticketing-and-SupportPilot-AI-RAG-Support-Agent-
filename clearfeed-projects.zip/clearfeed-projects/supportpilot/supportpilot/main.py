from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from urllib.parse import parse_qs

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from pydantic import BaseModel

from .agent import AgentResult, SupportAgent
from .config import Settings
from .embeddings import Embedder, HashingEmbedder
from .llm import LLM, AnthropicLLM, ExtractiveLLM
from .retriever import Retriever
from .slack import HttpSlackClient, SlackClient, approval_blocks, verify_slack_signature
from .store import KnowledgeStore
from .tools import ActionManager, ThreadDeskClient, default_tools


def utc_now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class AskIn(BaseModel):
    workspace_id: str
    question: str
    user_id: str = "api"


def format_reply(r: AgentResult) -> str:
    if r.action == "answer":
        sources = ", ".join(f"[{c['n']}] {c['source']} › {c['section']}" for c in r.citations)
        return f"{r.text}\n_Sources: {sources}_"
    if r.action == "handoff":
        draft = f"\n*Draft for the responder (model unavailable):*\n> {r.draft}" if r.draft else ""
        related = f"\n_Closest docs: {'; '.join(r.related)}_" if r.related else ""
        return f"{r.text}{related}{draft}"
    return r.text


def create_app(
    settings: Settings | None = None,
    store: KnowledgeStore | None = None,
    embedder: Embedder | None = None,
    llm: LLM | None = None,
    slack: SlackClient | None = None,
    threaddesk: ThreadDeskClient | None = None,
    clock=utc_now,
) -> FastAPI:
    settings = settings or Settings()
    store = store or KnowledgeStore(settings.db_path)
    embedder = embedder or HashingEmbedder()
    llm = llm or (AnthropicLLM(settings.anthropic_api_key, settings.llm_model) if settings.anthropic_api_key else ExtractiveLLM())
    slack = slack or HttpSlackClient(settings.slack_bot_token)
    threaddesk = threaddesk or ThreadDeskClient(settings.threaddesk_url, settings.threaddesk_api_key)

    retriever = Retriever(store, embedder, settings.retrieval_mode)
    actions = ActionManager(store, default_tools(threaddesk), clock, approver_ids=settings.approver_ids)
    agent = SupportAgent(retriever, llm, store, actions, clock, settings.confidence_threshold, settings.top_k)

    app = FastAPI(title="SupportPilot")
    app.state.agent, app.state.actions, app.state.store = agent, actions, store

    def require_key(x_api_key: str | None = Header(default=None)) -> None:
        if x_api_key != settings.api_key:
            raise HTTPException(401, "invalid api key")

    async def verified(request: Request) -> bytes:
        body = await request.body()
        if not verify_slack_signature(
            settings.slack_signing_secret, request.headers.get("x-slack-request-timestamp"), body,
            request.headers.get("x-slack-signature"), settings.slack_timestamp_tolerance_s,
        ):
            raise HTTPException(401, "bad slack signature")
        return body

    @app.get("/healthz")
    def healthz():
        return {"ok": True}

    @app.post("/ask", dependencies=[Depends(require_key)])
    def ask(body: AskIn):
        r = agent.ask(body.workspace_id, body.question, body.user_id)
        return {**r.__dict__}

    @app.post("/actions/{action_id}/approve", dependencies=[Depends(require_key)])
    def approve(action_id: int, workspace_id: str, approver: str):
        out = actions.decide(workspace_id, action_id, approver, True)
        return {"ok": out.ok, "message": out.message}

    @app.post("/actions/{action_id}/reject", dependencies=[Depends(require_key)])
    def reject(action_id: int, workspace_id: str, approver: str):
        out = actions.decide(workspace_id, action_id, approver, False)
        return {"ok": out.ok, "message": out.message}

    @app.post("/slack/events")
    async def slack_events(request: Request):
        payload = json.loads(await verified(request))
        if payload.get("type") == "url_verification":
            return {"challenge": payload["challenge"]}
        team, ev = payload.get("team_id", ""), payload.get("event", {})
        if not store.first_time(f"slack:{team}", payload.get("event_id", "")):
            return {"ok": True, "duplicate": True}
        if ev.get("type") == "app_mention" and not ev.get("bot_id"):
            question = re.sub(r"<@[A-Z0-9]+>", "", ev.get("text", "")).strip()
            thread = ev.get("thread_ts") or ev["ts"]
            r = agent.ask(team, question, ev.get("user", ""), ev["channel"], thread)
            if r.action == "proposal":
                row = actions.get(team, r.action_id)
                summary = f"`{row['tool']}` {row['args']}\nRequested by <@{row['requested_by']}>"
                slack.post_message(ev["channel"], r.text, thread, approval_blocks(r.action_id, summary))
            else:
                slack.post_message(ev["channel"], format_reply(r), thread)
        return {"ok": True}

    @app.post("/slack/interactions")
    async def slack_interactions(request: Request):
        payload = json.loads(parse_qs((await verified(request)).decode())["payload"][0])
        if payload.get("type") != "block_actions":
            return {"ok": True}
        act = payload["actions"][0]
        if act["action_id"] not in {"approve_action", "reject_action"}:
            return {"ok": True}
        team, user = payload["team"]["id"], payload["user"]["id"]
        out = actions.decide(team, int(act["value"]), user, act["action_id"] == "approve_action")
        slack.post_message(payload["channel"]["id"], f"<@{user}>: {out.message}", payload.get("message", {}).get("ts"))
        return {"ok": out.ok}

    return app
