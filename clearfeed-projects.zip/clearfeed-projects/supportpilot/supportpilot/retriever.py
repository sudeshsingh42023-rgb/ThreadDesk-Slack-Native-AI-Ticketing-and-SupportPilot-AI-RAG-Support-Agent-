from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .bm25 import BM25
from .embeddings import Embedder
from .store import KnowledgeStore, StoredChunk


@dataclass
class Hit:
    chunk: StoredChunk
    score: float  # fused score used for ranking
    cosine: float
    bm25: float


class _Index:
    def __init__(self, chunks: list[StoredChunk], matrix: np.ndarray):
        self.chunks, self.matrix = chunks, matrix
        self.bm25 = BM25([f"{c.heading}\n{c.text}" for c in chunks])


class Retriever:
    """bm25 | vector | hybrid (reciprocal rank fusion). Indexes are cached per workspace and rebuilt on change."""

    def __init__(self, store: KnowledgeStore, embedder: Embedder, mode: str = "hybrid", rrf_k: int = 60):
        assert mode in {"bm25", "vector", "hybrid"}
        self.store, self.embedder, self.mode, self.rrf_k = store, embedder, mode, rrf_k
        self._cache: dict[str, tuple[tuple[int, int], _Index]] = {}

    def index(self, workspace_id: str) -> _Index:
        version = self.store.version(workspace_id)
        cached = self._cache.get(workspace_id)
        if cached and cached[0] == version:
            return cached[1]
        idx = _Index(*self.store.load(workspace_id, self.embedder.dim))
        self._cache[workspace_id] = (version, idx)
        return idx

    def search(self, workspace_id: str, query: str, k: int = 4) -> list[Hit]:
        idx = self.index(workspace_id)
        if not idx.chunks:
            return []
        cos = idx.matrix @ self.embedder.embed([query])[0]
        bm = np.array(idx.bm25.scores(query))

        def ranks(scores: np.ndarray) -> np.ndarray:
            order = np.argsort(-scores, kind="stable")
            r = np.empty(len(scores), dtype=int)
            r[order] = np.arange(len(scores))
            return r

        if self.mode == "bm25":
            fused = bm
        elif self.mode == "vector":
            fused = cos
        else:
            fused = 1.0 / (self.rrf_k + ranks(cos) + 1) + 1.0 / (self.rrf_k + ranks(bm) + 1)
            fused = np.where((bm == 0) & (cos <= 0), 0.0, fused)
        top = np.argsort(-fused, kind="stable")[:k]
        return [Hit(idx.chunks[i], float(fused[i]), float(cos[i]), float(bm[i])) for i in top]
