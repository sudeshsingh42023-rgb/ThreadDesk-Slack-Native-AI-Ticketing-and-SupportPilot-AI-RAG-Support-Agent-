"""Prompt-injection and output defenses.

Retrieved text is untrusted. We (1) drop passages that look like instructions aimed at the model, (2) wrap what
remains in <source> tags with an instruction to treat it as data, and (3) validate the model's answer: citations must
point at real passages, and URLs / e-mail addresses that do not appear in the cited passages are stripped.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

INJECTION_PATTERNS = [
    r"ignore (all |any |the )?(previous|prior|above|earlier) (instructions|prompts?|rules)",
    r"disregard (all |any |the )?(previous|prior|above|earlier)?\s*(instructions|prompts?|rules)",
    r"(reveal|print|show|leak) (your |the )?(system prompt|hidden instructions|api key|secrets?)",
    r"you are now\b",
    r"<\s*/?\s*(system|assistant|instructions?)\s*>",
    r"\bnew instructions\s*:",
]
_INJ = re.compile("|".join(INJECTION_PATTERNS), re.I)
URL_RE = re.compile(r"https?://[^\s)>\]]+", re.I)
EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
CITE_RE = re.compile(r"\[(\d+)\]")


def looks_like_injection(text: str) -> bool:
    return bool(_INJ.search(text))


@dataclass
class Validation:
    ok: bool
    text: str
    citations: list[int] = field(default_factory=list)
    removed: list[str] = field(default_factory=list)
    reason: str = ""


def validate_answer(answer: str, passages: dict[int, str]) -> Validation:
    """`passages` maps citation number -> passage text shown to the model."""
    cited = [int(n) for n in CITE_RE.findall(answer)]
    valid = sorted({n for n in cited if n in passages})
    if not valid:
        return Validation(False, answer, reason="no_valid_citation")
    cited_text = " ".join(passages[n] for n in valid)
    removed: list[str] = []

    def scrub(match: re.Match) -> str:
        token = match.group(0)
        if token.rstrip(".,") in cited_text:
            return token
        removed.append(token)
        return "[removed]"

    cleaned = EMAIL_RE.sub(scrub, URL_RE.sub(scrub, answer))
    # drop citation markers that point nowhere
    cleaned = CITE_RE.sub(lambda m: m.group(0) if int(m.group(1)) in passages else "", cleaned)
    return Validation(True, cleaned, valid, removed)
