from __future__ import annotations

import hashlib
import hmac
import time
from typing import Protocol

import httpx


def verify_slack_signature(secret, timestamp, body: bytes, signature, tolerance_s=300, now=None) -> bool:
    try:
        ts = int(timestamp or "")
    except ValueError:
        return False
    if abs((now if now is not None else time.time()) - ts) > tolerance_s:
        return False
    expected = "v0=" + hmac.new(secret.encode(), f"v0:{timestamp}:".encode() + body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature or "")


class SlackClient(Protocol):
    def post_message(self, channel: str, text: str, thread_ts: str | None = None, blocks: list[dict] | None = None) -> None: ...


class HttpSlackClient:
    def __init__(self, token: str, client: httpx.Client | None = None):
        self.token, self.client = token, client or httpx.Client(timeout=10)

    def post_message(self, channel, text, thread_ts=None, blocks=None):
        payload = {"channel": channel, "text": text}
        if thread_ts:
            payload["thread_ts"] = thread_ts
        if blocks:
            payload["blocks"] = blocks
        r = self.client.post("https://slack.com/api/chat.postMessage", headers={"Authorization": f"Bearer {self.token}"}, json=payload)
        r.raise_for_status()
        if not r.json().get("ok"):
            raise RuntimeError(f"slack error: {r.json().get('error')}")


class FakeSlackClient:
    def __init__(self):
        self.messages: list[dict] = []

    def post_message(self, channel, text, thread_ts=None, blocks=None):
        self.messages.append({"channel": channel, "text": text, "thread_ts": thread_ts, "blocks": blocks})


def approval_blocks(action_id: int, summary: str) -> list[dict]:
    return [
        {"type": "section", "text": {"type": "mrkdwn", "text": f"*Approval needed (action #{action_id})*\n{summary}"}},
        {
            "type": "actions",
            "elements": [
                {"type": "button", "style": "primary", "text": {"type": "plain_text", "text": "Approve"}, "action_id": "approve_action", "value": str(action_id)},
                {"type": "button", "style": "danger", "text": {"type": "plain_text", "text": "Reject"}, "action_id": "reject_action", "value": str(action_id)},
            ],
        },
    ]
