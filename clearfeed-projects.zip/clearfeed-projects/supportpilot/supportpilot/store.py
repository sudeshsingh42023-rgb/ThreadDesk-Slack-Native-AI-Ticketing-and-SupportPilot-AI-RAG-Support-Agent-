"""SQLite-backed knowledge store. Every query is scoped by workspace_id."""
from __future__ import annotations

import sqlite3
import threading
from dataclasses import dataclass

import numpy as np

from .chunking import Chunk

SCHEMA = """
CREATE TABLE IF NOT EXISTS chunks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  workspace_id TEXT NOT NULL, source TEXT NOT NULL, heading TEXT NOT NULL, idx INTEGER NOT NULL,
  text TEXT NOT NULL, embedding BLOB NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_chunks_ws ON chunks(workspace_id);
CREATE TABLE IF NOT EXISTS actions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  workspace_id TEXT NOT NULL, tool TEXT NOT NULL, args TEXT NOT NULL, requested_by TEXT NOT NULL,
  channel_id TEXT NOT NULL, thread_ts TEXT,
  status TEXT NOT NULL DEFAULT 'pending', decided_by TEXT, result TEXT, created_at TEXT NOT NULL, decided_at TEXT
);
CREATE TABLE IF NOT EXISTS audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, workspace_id TEXT NOT NULL,
  actor TEXT NOT NULL, event TEXT NOT NULL, detail TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS processed_events (source TEXT NOT NULL, event_id TEXT NOT NULL, PRIMARY KEY (source, event_id));
"""


@dataclass
class StoredChunk:
    id: int
    workspace_id: str
    source: str
    heading: str
    text: str


class KnowledgeStore:
    def __init__(self, path: str = ":memory:"):
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        with self.lock:
            self.conn.executescript(SCHEMA)

    # ---- knowledge ---------------------------------------------------------------------------------------
    def replace_source(self, workspace_id: str, source: str, chunks: list[Chunk], embeddings: np.ndarray) -> None:
        with self.lock, self.conn:
            self.conn.execute("DELETE FROM chunks WHERE workspace_id=? AND source=?", (workspace_id, source))
            self.conn.executemany(
                "INSERT INTO chunks(workspace_id, source, heading, idx, text, embedding) VALUES (?,?,?,?,?,?)",
                [
                    (workspace_id, c.source, c.heading, c.idx, c.text, emb.astype(np.float32).tobytes())
                    for c, emb in zip(chunks, embeddings)
                ],
            )

    def version(self, workspace_id: str) -> tuple[int, int]:
        with self.lock:
            r = self.conn.execute(
                "SELECT COUNT(*) c, COALESCE(MAX(id),0) m FROM chunks WHERE workspace_id=?", (workspace_id,)
            ).fetchone()
        return r["c"], r["m"]

    def load(self, workspace_id: str, dim: int) -> tuple[list[StoredChunk], np.ndarray]:
        with self.lock:
            rows = self.conn.execute(
                "SELECT id, workspace_id, source, heading, text, embedding FROM chunks WHERE workspace_id=? ORDER BY id",
                (workspace_id,),
            ).fetchall()
        chunks = [StoredChunk(r["id"], r["workspace_id"], r["source"], r["heading"], r["text"]) for r in rows]
        matrix = (
            np.vstack([np.frombuffer(r["embedding"], dtype=np.float32) for r in rows])
            if rows
            else np.zeros((0, dim), dtype=np.float32)
        )
        return chunks, matrix

    # ---- audit / idempotency -----------------------------------------------------------------------------
    def audit(self, ts: str, workspace_id: str, actor: str, event: str, detail: str) -> None:
        with self.lock, self.conn:
            self.conn.execute(
                "INSERT INTO audit(ts, workspace_id, actor, event, detail) VALUES (?,?,?,?,?)",
                (ts, workspace_id, actor, event, detail),
            )

    def audit_rows(self, workspace_id: str) -> list[sqlite3.Row]:
        with self.lock:
            return self.conn.execute("SELECT * FROM audit WHERE workspace_id=? ORDER BY id", (workspace_id,)).fetchall()

    def first_time(self, source: str, event_id: str) -> bool:
        with self.lock, self.conn:
            cur = self.conn.execute("INSERT OR IGNORE INTO processed_events VALUES (?,?)", (source, event_id))
            return cur.rowcount == 1
