import re

STOP = frozenset(
    "a an the and or but if then of to in on at for from by with as is are was were be been being it its this that "
    "these those i you we they he she do does did can could should would will may might my your our their me us how "
    "what when where which who whom why there here not no yes any some about into than so such also just very am get getting got much many long fast quickly often tell give please need want".split()
)


def stem(w: str) -> str:
    if len(w) > 4 and w.endswith("ies"):
        return w[:-3] + "y"
    if len(w) > 5 and w.endswith("ing"):
        return w[:-3]
    if len(w) > 4 and w.endswith("ed"):
        return w[:-2]
    if len(w) > 3 and w.endswith("s") and not w.endswith("ss"):
        return w[:-1]
    return w


def tokens(text: str, keep_stop: bool = False) -> list[str]:
    words = re.findall(r"[a-z0-9]+", text.lower())
    return [stem(w) for w in words if keep_stop or w not in STOP]


def sentences(text: str) -> list[str]:
    """Split on sentence ends and on markdown line breaks / bullets / table rows."""
    out: list[str] = []
    for line in text.splitlines():
        line = line.strip().lstrip("-*• ").strip()
        if not line or line.startswith("#") or set(line) <= set("|-: "):
            continue
        out.extend(p.strip() for p in re.split(r"(?<=[.!?])\s+(?=[A-Z0-9`])", line) if p.strip())
    return out
