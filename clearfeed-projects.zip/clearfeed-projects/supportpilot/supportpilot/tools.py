"""Tool registry + human-approval workflow.

Read-only tools run immediately. Tools that change state require an explicit approve step from a person; the
arguments are validated when proposed AND again at execution time, every step is audited, and each action is scoped
to one workspace so approvers in tenant A can never touch tenant B's pending actions.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Callable

import httpx
from pydantic import BaseModel, Field, ValidationError

from .store import KnowledgeStore


@dataclass
class ToolContext:
    workspace_id: str
    channel_id: str
    user_id: str


class CreateTicketArgs(BaseModel):
    title: str = Field(min_length=3, max_length=200)
    body: str = Field(default="", max_length=4000)


class TicketStatusArgs(BaseModel):
    ticket_id: int = Field(gt=0)


class ThreadDeskClient:
    """HTTP client for the ThreadDesk REST API (project 1)."""

    def __init__(self, base_url: str, api_key: str, client: httpx.Client | None = None):
        self.client = client or httpx.Client(base_url=base_url, headers={"X-API-Key": api_key}, timeout=10)

    def create_ticket(self, workspace_id: str, channel_id: str, author_id: str, title: str, body: str) -> dict:
        r = self.client.post(
            "/api/tickets",
            json={"workspace_id": workspace_id, "channel_id": channel_id, "author_id": author_id, "title": title, "body": body},
        )
        r.raise_for_status()
        return r.json()

    def get_ticket(self, workspace_id: str, ticket_id: int) -> dict | None:
        r = self.client.get(f"/api/tickets/{ticket_id}", params={"workspace_id": workspace_id})
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.json()


@dataclass
class Tool:
    name: str
    description: str
    args_model: type[BaseModel]
    requires_approval: bool
    run: Callable[[ToolContext, BaseModel], str]


def default_tools(td: ThreadDeskClient) -> dict[str, Tool]:
    def create_ticket(ctx: ToolContext, a: CreateTicketArgs) -> str:
        t = td.create_ticket(ctx.workspace_id, ctx.channel_id, ctx.user_id, a.title, a.body)
        return f"Created ticket #{t['id']} ({t['category']}, priority {t['priority']})."

    def ticket_status(ctx: ToolContext, a: TicketStatusArgs) -> str:
        t = td.get_ticket(ctx.workspace_id, a.ticket_id)
        if t is None:
            return f"No ticket #{a.ticket_id} found."
        gh = f", GitHub #{t['github_issue_number']}" if t.get("github_issue_number") else ""
        return f"Ticket #{t['id']} is {t['status']} ({t['category']}/{t['priority']}{gh})."

    return {
        "create_ticket": Tool("create_ticket", "Open a support ticket", CreateTicketArgs, True, create_ticket),
        "ticket_status": Tool("ticket_status", "Look up ticket status", TicketStatusArgs, False, ticket_status),
    }


@dataclass
class ActionOutcome:
    ok: bool
    message: str
    action_id: int | None = None
    needs_approval: bool = False


class ActionManager:
    def __init__(
        self,
        store: KnowledgeStore,
        tools: dict[str, Tool],
        clock: Callable[[], datetime],
        policy: Callable[[str], set[str]] | None = None,
        approver_ids: str = "",
    ):
        self.store, self.tools, self.clock = store, tools, clock
        self.policy = policy or (lambda _ws: set(tools))
        self.approvers = {a.strip() for a in approver_ids.split(",") if a.strip()}

    def _now(self) -> str:
        return self.clock().isoformat()

    def _audit(self, ws: str, actor: str, event: str, detail: dict) -> None:
        self.store.audit(self._now(), ws, actor, event, json.dumps(detail, sort_keys=True))

    def propose(self, tool_name: str, raw_args: dict, ctx: ToolContext, thread_ts: str | None = None) -> ActionOutcome:
        tool = self.tools.get(tool_name)
        if tool is None or tool_name not in self.policy(ctx.workspace_id):
            self._audit(ctx.workspace_id, ctx.user_id, "tool_denied", {"tool": tool_name})
            return ActionOutcome(False, f"Tool '{tool_name}' is not allowed in this workspace.")
        try:
            args = tool.args_model.model_validate(raw_args)
        except ValidationError as exc:
            self._audit(ctx.workspace_id, ctx.user_id, "args_invalid", {"tool": tool_name})
            return ActionOutcome(False, f"Invalid arguments: {exc.errors()[0]['msg']}")

        if not tool.requires_approval:
            msg = tool.run(ctx, args)
            self._audit(ctx.workspace_id, ctx.user_id, "tool_executed", {"tool": tool_name, "args": args.model_dump()})
            return ActionOutcome(True, msg)

        with self.store.lock, self.store.conn:
            cur = self.store.conn.execute(
                "INSERT INTO actions(workspace_id, tool, args, requested_by, channel_id, thread_ts, status, created_at)"
                " VALUES (?,?,?,?,?,?,'pending',?)",
                (ctx.workspace_id, tool_name, args.model_dump_json(), ctx.user_id, ctx.channel_id, thread_ts, self._now()),
            )
            action_id = cur.lastrowid
        self._audit(ctx.workspace_id, ctx.user_id, "action_proposed", {"id": action_id, "tool": tool_name, "args": args.model_dump()})
        return ActionOutcome(True, f"Action #{action_id} is waiting for approval.", action_id, needs_approval=True)

    def get(self, workspace_id: str, action_id: int):
        with self.store.lock:
            return self.store.conn.execute(
                "SELECT * FROM actions WHERE id=? AND workspace_id=?", (action_id, workspace_id)
            ).fetchone()

    def decide(self, workspace_id: str, action_id: int, approver: str, approve: bool) -> ActionOutcome:
        row = self.get(workspace_id, action_id)
        if row is None:
            return ActionOutcome(False, "Action not found.")
        if self.approvers and approver not in self.approvers:
            self._audit(workspace_id, approver, "approval_denied", {"id": action_id})
            return ActionOutcome(False, "You are not allowed to approve actions.")
        if row["status"] != "pending":
            return ActionOutcome(False, f"Action #{action_id} was already {row['status']}.")

        # claim the row atomically so a double click cannot execute twice
        new_status = "approved" if approve else "rejected"
        with self.store.lock, self.store.conn:
            claimed = self.store.conn.execute(
                "UPDATE actions SET status=?, decided_by=?, decided_at=? WHERE id=? AND workspace_id=? AND status='pending'",
                (new_status, approver, self._now(), action_id, workspace_id),
            ).rowcount
        if claimed != 1:
            return ActionOutcome(False, f"Action #{action_id} was already decided.")
        self._audit(workspace_id, approver, f"action_{new_status}", {"id": action_id, "tool": row["tool"]})
        if not approve:
            return ActionOutcome(True, f"Action #{action_id} rejected.", action_id)

        tool = self.tools[row["tool"]]
        ctx = ToolContext(workspace_id, row["channel_id"], row["requested_by"])
        try:
            args = tool.args_model.model_validate_json(row["args"])  # re-validate at execution time
            message = tool.run(ctx, args)
            status, ok = "executed", True
        except Exception as exc:  # noqa: BLE001
            message, status, ok = f"Execution failed: {type(exc).__name__}", "failed", False
        with self.store.lock, self.store.conn:
            self.store.conn.execute("UPDATE actions SET status=?, result=? WHERE id=?", (status, message, action_id))
        self._audit(workspace_id, approver, f"action_{status}", {"id": action_id, "result": message})
        return ActionOutcome(ok, message, action_id)
