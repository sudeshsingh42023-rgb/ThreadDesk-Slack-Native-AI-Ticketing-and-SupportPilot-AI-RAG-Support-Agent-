import hashlib
import hmac
import json
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import urlencode

import httpx
import pytest
from fastapi.testclient import TestClient

from supportpilot.config import Settings
from supportpilot.embeddings import HashingEmbedder
from supportpilot.ingest import ingest_directory
from supportpilot.main import create_app
from supportpilot.slack import FakeSlackClient
from supportpilot.store import KnowledgeStore
from supportpilot.tools import ThreadDeskClient

KB = Path(__file__).resolve().parent.parent / "eval" / "kb"
SECRET = "test-secret"


class FakeThreadDesk:
    """httpx MockTransport standing in for the ThreadDesk REST API; records every request."""

    def __init__(self):
        self.requests: list[httpx.Request] = []
        self.client = ThreadDeskClient(
            "http://threaddesk", "k", client=httpx.Client(base_url="http://threaddesk", transport=httpx.MockTransport(self._handle))
        )

    def _handle(self, req: httpx.Request) -> httpx.Response:
        self.requests.append(req)
        if req.method == "POST" and req.url.path == "/api/tickets":
            return httpx.Response(200, json={"id": 7, "status": "open", "category": "bug", "priority": "high"})
        if req.method == "GET" and req.url.path == "/api/tickets/7":
            return httpx.Response(200, json={"id": 7, "status": "in_progress", "category": "bug", "priority": "high", "github_issue_number": 42})
        return httpx.Response(404, json={})


@pytest.fixture
def store():
    s = KnowledgeStore(":memory:")
    ingest_directory(s, HashingEmbedder(), "T1", KB)
    return s


@pytest.fixture
def env(store):
    slack, td = FakeSlackClient(), FakeThreadDesk()
    settings = Settings(api_key="k", slack_signing_secret=SECRET, db_path=":memory:")
    app = create_app(settings, store=store, slack=slack, threaddesk=td.client, clock=lambda: datetime(2026, 10, 7, 9, 0))
    with TestClient(app) as client:
        yield type("Env", (), {"client": client, "app": app, "slack": slack, "td": td, "store": store, "agent": app.state.agent, "actions": app.state.actions})


def sign(body: bytes, ts=None, secret=SECRET):
    ts = str(ts if ts is not None else int(time.time()))
    sig = "v0=" + hmac.new(secret.encode(), f"v0:{ts}:".encode() + body, hashlib.sha256).hexdigest()
    return {"X-Slack-Request-Timestamp": ts, "X-Slack-Signature": sig}


def mention(env, text, user="U1", team="T1", event_id="Ev1", channel="C1", ts="100.1"):
    body = json.dumps({"type": "event_callback", "team_id": team, "event_id": event_id,
                       "event": {"type": "app_mention", "user": user, "text": f"<@UBOT> {text}", "channel": channel, "ts": ts}}).encode()
    return env.client.post("/slack/events", content=body, headers={**sign(body), "Content-Type": "application/json"})


def click(env, action_id, value, user="U2", team="T1"):
    payload = {"type": "block_actions", "team": {"id": team}, "user": {"id": user}, "channel": {"id": "C1"},
               "message": {"ts": "100.1"}, "actions": [{"action_id": action_id, "value": str(value)}]}
    body = urlencode({"payload": json.dumps(payload)}).encode()
    return env.client.post("/slack/interactions", content=body, headers={**sign(body), "Content-Type": "application/x-www-form-urlencoded"})
