# ThreadDesk

Slack-native AI ticketing with two-way GitHub Issues sync. Turn support threads in Slack into tracked tickets,
triage them with an LLM (with a deterministic fallback), keep them in sync with GitHub, and watch response SLAs.

## What it does

- **Thread → ticket**: message shortcut (`create_ticket`), `/ticket <text>`, or automatic detection in configured channels.
- **AI triage**: category, priority, one-line summary and "needs a human reply?" from an LLM. Output is schema-validated;
  on any failure (timeout, bad JSON, invalid enum) a keyword heuristic takes over, so a ticket is never lost.
  The user's text is passed inside `<message>` tags and treated as untrusted data.
- **Two-way sync with GitHub**: Slack → issue (create, close/reopen, mirrored replies as comments) and
  GitHub → Slack (closed/reopened, assignee, human comments) via signed webhooks.
- **SLA tracking**: one reminder per ticket when nobody replies within the workspace SLA; first-response and
  closure times per channel, shown on the Slack Home tab and at `GET /api/workspaces/{id}/metrics`.
- **Multi-tenant**: every table carries `workspace_id`; every lookup is scoped by it (see `test_tenant_isolation`).

## Architecture

```
Slack ──events/commands/shortcuts──▶ FastAPI ──▶ TicketService ──▶ DB (tickets, audit, outbox)
GitHub ─────────webhooks───────────▶   │                              │
                                       └── verify signatures,         ▼
                                           dedupe event ids      Worker (outbox)
                                                                   ├─▶ Slack API   (retry w/ backoff)
                                                                   └─▶ GitHub API  (retry w/ backoff)
```

Design decisions worth knowing:

1. **Ack fast, work later.** Slack needs a 200 within 3 s. Handlers only write to the DB; Slack/GitHub calls are rows
   in a transactional outbox (`jobs`) executed by a worker with exponential backoff (5 s, 10 s, 20 s, …) and a
   dead-letter state after `JOB_MAX_ATTEMPTS`. On Postgres the worker claims rows with `FOR UPDATE SKIP LOCKED`.
2. **Idempotency.** Slack `event_id` and GitHub `X-GitHub-Delivery` are stored in `processed_events`; a
   redelivery is acknowledged and skipped. One ticket per `(workspace, channel, thread_ts)` is enforced by a unique constraint.
3. **No sync loops.** Three independent guards: (a) state convergence, closing an already-closed ticket is a no-op, so
   GitHub's echo of our own `closed` write does nothing; (b) every comment we mirror carries `[via ThreadDesk]` and is ignored
   when it comes back; (c) optional `GITHUB_BOT_LOGIN` ignores events from the bot account. Slack bot messages are ignored on input.
4. **Security.** Slack v0 request signatures with a 5-minute replay window; GitHub `X-Hub-Signature-256`; constant-time compares; REST API behind an API key.

## Run it

```bash
pip install -r requirements.txt
cp .env.example .env            # fill in Slack/GitHub secrets
uvicorn app.main:create_app --factory --reload
pytest -q                        # 29 tests, no network needed (Slack/GitHub/LLM are faked)
docker compose up --build        # API + Postgres
```

Slack app setup: Event Subscriptions → `/slack/events` (`message.channels`, `app_home_opened`); Slash command `/ticket` →
`/slack/commands`; Interactivity → `/slack/interactions` with a message shortcut whose callback ID is `create_ticket`.
GitHub: webhook → `/github/webhook`, events *Issues* and *Issue comments*, same secret as `GITHUB_WEBHOOK_SECRET`.

## Known limitations (and what I would do next)

- Delivery is at-least-once. If the process dies after GitHub accepts a new issue but before the DB commit, a retry
  creates a duplicate issue. Fix: look the issue up by a hidden marker before creating.
- Replies sent in Slack before the GitHub issue exists are not mirrored.
- Bot tokens come from env vars for a single install; a production version needs the Slack OAuth flow with per-workspace encrypted tokens.
- Workspace settings (repo, SLA, auto-detect channels) are set in the DB; there is no admin UI yet.
- SQLite is used for tests and local dev; the Postgres path via `docker compose` is configured but not exercised by the test suite.
