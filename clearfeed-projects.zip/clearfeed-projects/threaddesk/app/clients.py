"""Thin Slack / GitHub clients behind Protocols, plus in-memory fakes used by tests and local demos."""
from __future__ import annotations

from typing import Protocol

import httpx


class SlackClient(Protocol):
    def post_message(self, channel: str, text: str, thread_ts: str | None = None) -> None: ...
    def publish_home(self, user_id: str, blocks: list[dict]) -> None: ...


class GitHubClient(Protocol):
    def create_issue(self, repo: str, title: str, body: str, labels: list[str]) -> int: ...
    def comment(self, repo: str, number: int, body: str) -> None: ...
    def set_state(self, repo: str, number: int, state: str) -> None: ...


class HttpSlackClient:
    def __init__(self, token: str, client: httpx.Client | None = None):
        self.token = token
        self.client = client or httpx.Client(timeout=10)

    def _call(self, method: str, payload: dict) -> None:
        resp = self.client.post(
            f"https://slack.com/api/{method}",
            headers={"Authorization": f"Bearer {self.token}"},
            json=payload,
        )
        resp.raise_for_status()
        data = resp.json()
        if not data.get("ok"):
            raise RuntimeError(f"slack {method} failed: {data.get('error')}")

    def post_message(self, channel: str, text: str, thread_ts: str | None = None) -> None:
        payload = {"channel": channel, "text": text}
        if thread_ts:
            payload["thread_ts"] = thread_ts
        self._call("chat.postMessage", payload)

    def publish_home(self, user_id: str, blocks: list[dict]) -> None:
        self._call("views.publish", {"user_id": user_id, "view": {"type": "home", "blocks": blocks}})


class HttpGitHubClient:
    def __init__(self, token: str, client: httpx.Client | None = None):
        self.client = client or httpx.Client(
            timeout=10,
            base_url="https://api.github.com",
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            },
        )

    def create_issue(self, repo: str, title: str, body: str, labels: list[str]) -> int:
        r = self.client.post(f"/repos/{repo}/issues", json={"title": title, "body": body, "labels": labels})
        r.raise_for_status()
        return int(r.json()["number"])

    def comment(self, repo: str, number: int, body: str) -> None:
        self.client.post(f"/repos/{repo}/issues/{number}/comments", json={"body": body}).raise_for_status()

    def set_state(self, repo: str, number: int, state: str) -> None:
        self.client.patch(f"/repos/{repo}/issues/{number}", json={"state": state}).raise_for_status()


class FakeSlackClient:
    def __init__(self):
        self.messages: list[dict] = []
        self.home_views: list[dict] = []
        self.fail_next = 0  # simulate transient outages

    def post_message(self, channel, text, thread_ts=None):
        if self.fail_next > 0:
            self.fail_next -= 1
            raise RuntimeError("simulated slack outage")
        self.messages.append({"channel": channel, "text": text, "thread_ts": thread_ts})

    def publish_home(self, user_id, blocks):
        self.home_views.append({"user_id": user_id, "blocks": blocks})


class FakeGitHubClient:
    def __init__(self):
        self.issues: dict[tuple[str, int], dict] = {}
        self.comments: list[dict] = []
        self._next = 1
        self.fail_next = 0

    def create_issue(self, repo, title, body, labels):
        if self.fail_next > 0:
            self.fail_next -= 1
            raise RuntimeError("simulated github outage")
        number, self._next = self._next, self._next + 1
        self.issues[(repo, number)] = {"title": title, "body": body, "labels": labels, "state": "open"}
        return number

    def comment(self, repo, number, body):
        self.comments.append({"repo": repo, "number": number, "body": body})

    def set_state(self, repo, number, state):
        self.issues[(repo, number)]["state"] = state
