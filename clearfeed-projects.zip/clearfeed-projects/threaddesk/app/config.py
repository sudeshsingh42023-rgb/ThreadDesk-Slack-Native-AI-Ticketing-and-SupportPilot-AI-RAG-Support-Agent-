from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "sqlite:///./threaddesk.db"
    slack_signing_secret: str = "dev-signing-secret"
    slack_bot_token: str = ""
    github_token: str = ""
    github_webhook_secret: str = "dev-webhook-secret"
    github_bot_login: str = ""  # optional extra echo guard; leave empty if the bot uses a human account
    default_github_repo: str = ""
    anthropic_api_key: str = ""
    llm_model: str = "claude-sonnet-4-6"
    api_key: str = "dev-api-key"
    slack_timestamp_tolerance_s: int = 300
    default_sla_minutes: int = 60
    worker_enabled: bool = True
    worker_interval_s: float = 2.0
    job_max_attempts: int = 5
    job_backoff_base_s: int = 5
