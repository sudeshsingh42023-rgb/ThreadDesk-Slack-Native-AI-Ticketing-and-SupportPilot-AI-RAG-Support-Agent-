from __future__ import annotations

import json
import threading
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from urllib.parse import parse_qs

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from pydantic import BaseModel

from .clients import GitHubClient, HttpGitHubClient, HttpSlackClient, SlackClient
from .config import Settings
from .db import make_session_factory, session_scope
from .security import verify_github_signature, verify_slack_signature
from .service import TicketService, channel_metrics, home_blocks, mark_processed
from .triage import HeuristicTriager, LLMTriager, Triager
from .worker import Worker


def utc_now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class ApiTicketIn(BaseModel):
    workspace_id: str
    channel_id: str
    author_id: str
    title: str
    body: str = ""


def create_app(
    settings: Settings | None = None,
    slack: SlackClient | None = None,
    github: GitHubClient | None = None,
    triager: Triager | None = None,
    clock=utc_now,
) -> FastAPI:
    settings = settings or Settings()
    sf = make_session_factory(settings.database_url)
    slack = slack or HttpSlackClient(settings.slack_bot_token)
    github = github or HttpGitHubClient(settings.github_token)
    if triager is None:
        triager = (
            LLMTriager(settings.anthropic_api_key, settings.llm_model)
            if settings.anthropic_api_key
            else HeuristicTriager()
        )
    service = TicketService(triager, clock, settings.default_github_repo, settings.default_sla_minutes)
    worker = Worker(sf, slack, github, service, clock, settings.job_max_attempts, settings.job_backoff_base_s)

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        thread = None
        if settings.worker_enabled:
            thread = threading.Thread(target=worker.run_forever, args=(settings.worker_interval_s,), daemon=True)
            thread.start()
        yield
        worker.stop()

    app = FastAPI(title="ThreadDesk", lifespan=lifespan)
    app.state.sf, app.state.service, app.state.worker, app.state.settings = sf, service, worker, settings

    def require_api_key(x_api_key: str | None = Header(default=None)) -> None:
        if x_api_key != settings.api_key:
            raise HTTPException(401, "invalid api key")

    async def verified_body(request: Request) -> bytes:
        body = await request.body()
        if not verify_slack_signature(
            settings.slack_signing_secret,
            request.headers.get("x-slack-request-timestamp"),
            body,
            request.headers.get("x-slack-signature"),
            settings.slack_timestamp_tolerance_s,
        ):
            raise HTTPException(401, "bad slack signature")
        return body

    @app.get("/healthz")
    def healthz():
        return {"ok": True}

    # ---- Slack: events -----------------------------------------------------------------------------------
    @app.post("/slack/events")
    async def slack_events(request: Request):
        body = await verified_body(request)
        payload = json.loads(body)
        if payload.get("type") == "url_verification":
            return {"challenge": payload["challenge"]}

        team_id, event_id, event = payload.get("team_id", ""), payload.get("event_id", ""), payload.get("event", {})
        with session_scope(sf) as s:
            if not mark_processed(s, f"slack:{team_id}", event_id, clock()):
                return {"ok": True, "duplicate": True}  # Slack retried; already handled

            if event.get("type") == "message":
                if event.get("bot_id") or event.get("subtype"):
                    return {"ok": True}  # never react to bots (including ourselves) or edits/joins
                channel, user, text, ts = event["channel"], event.get("user", ""), event.get("text", ""), event["ts"]
                thread_ts = event.get("thread_ts")
                if thread_ts and thread_ts != ts:
                    service.handle_reply(s, team_id, channel, thread_ts, user, text)
                else:
                    ws = service.ensure_workspace(s, team_id)
                    if channel in ws.auto_channels() and triager.triage(text).needs_response:
                        service.create_ticket(s, team_id, channel, user, text, thread_ts=ts)
            elif event.get("type") == "app_home_opened":
                blocks = home_blocks(channel_metrics(s, team_id))
                slack.publish_home(event["user"], blocks)
        return {"ok": True}

    # ---- Slack: slash command + message shortcut ---------------------------------------------------------
    @app.post("/slack/commands")
    async def slack_commands(request: Request):
        form = {k: v[0] for k, v in parse_qs((await verified_body(request)).decode()).items()}
        team, channel, user, text = form["team_id"], form["channel_id"], form["user_id"], form.get("text", "").strip()
        with session_scope(sf) as s:
            parts = text.split()
            if parts and parts[0] in {"close", "reopen", "status"} and len(parts) == 2 and parts[1].isdigit():
                ticket = service.get_ticket(s, team, int(parts[1]))
                if ticket is None:
                    return {"response_type": "ephemeral", "text": "Ticket not found."}
                if parts[0] == "close":
                    changed = service.close_ticket(s, ticket, "slack")
                    return {"response_type": "ephemeral", "text": "Closed." if changed else "Already closed."}
                if parts[0] == "reopen":
                    changed = service.reopen_ticket(s, ticket, "slack")
                    return {"response_type": "ephemeral", "text": "Reopened." if changed else "Not closed."}
                return {
                    "response_type": "ephemeral",
                    "text": f"#{ticket.id} {ticket.status} · {ticket.category}/{ticket.priority}"
                    + (f" · GitHub #{ticket.github_issue_number}" if ticket.github_issue_number else ""),
                }
            if not text:
                return {"response_type": "ephemeral", "text": "Usage: /ticket <describe the issue> | close <id> | reopen <id> | status <id>"}
            ticket, _ = service.create_ticket(s, team, channel, user, text)
            return {"response_type": "ephemeral", "text": f"Created ticket #{ticket.id}."}

    @app.post("/slack/interactions")
    async def slack_interactions(request: Request):
        form = parse_qs((await verified_body(request)).decode())
        payload = json.loads(form["payload"][0])
        if payload.get("type") == "message_action" and payload.get("callback_id") == "create_ticket":
            msg = payload["message"]
            with session_scope(sf) as s:
                ticket, created = service.create_ticket(
                    s,
                    payload["team"]["id"],
                    payload["channel"]["id"],
                    msg.get("user", payload["user"]["id"]),
                    msg.get("text", ""),
                    thread_ts=msg.get("thread_ts") or msg["ts"],
                )
            return {"ticket_id": ticket.id, "created": created}
        return {"ok": True}

    # ---- GitHub webhook ----------------------------------------------------------------------------------
    @app.post("/github/webhook")
    async def github_webhook(
        request: Request,
        x_github_event: str = Header(default=""),
        x_github_delivery: str = Header(default=""),
        x_hub_signature_256: str | None = Header(default=None),
    ):
        body = await request.body()
        if not verify_github_signature(settings.github_webhook_secret, body, x_hub_signature_256):
            raise HTTPException(401, "bad github signature")
        payload = json.loads(body)
        with session_scope(sf) as s:
            if not mark_processed(s, "github", x_github_delivery, clock()):
                return {"result": "duplicate"}
            result = service.apply_github_event(s, x_github_event, payload, settings.github_bot_login)
        return {"result": result}

    # ---- REST API (used by SupportPilot and dashboards) --------------------------------------------------
    @app.post("/api/tickets", dependencies=[Depends(require_api_key)])
    def api_create_ticket(body: ApiTicketIn):
        with session_scope(sf) as s:
            text = f"{body.title}\n{body.body}".strip()
            ticket, _ = service.create_ticket(s, body.workspace_id, body.channel_id, body.author_id, text)
            return {"id": ticket.id, "status": ticket.status, "category": ticket.category, "priority": ticket.priority}

    @app.get("/api/tickets/{ticket_id}", dependencies=[Depends(require_api_key)])
    def api_get_ticket(ticket_id: int, workspace_id: str):
        with session_scope(sf) as s:
            t = service.get_ticket(s, workspace_id, ticket_id)
            if t is None:
                raise HTTPException(404, "not found")
            return {
                "id": t.id,
                "status": t.status,
                "category": t.category,
                "priority": t.priority,
                "assignee": t.assignee,
                "github_issue_number": t.github_issue_number,
            }

    @app.get("/api/workspaces/{workspace_id}/metrics", dependencies=[Depends(require_api_key)])
    def api_metrics(workspace_id: str):
        with session_scope(sf) as s:
            return channel_metrics(s, workspace_id)

    return app
