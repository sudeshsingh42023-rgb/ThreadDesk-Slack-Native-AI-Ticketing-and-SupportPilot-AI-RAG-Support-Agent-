from __future__ import annotations

from datetime import datetime

from sqlalchemy import JSON, DateTime, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class Workspace(Base):
    """One row per Slack workspace (tenant). Every other table is keyed by workspace_id."""

    __tablename__ = "workspaces"

    id: Mapped[str] = mapped_column(String(32), primary_key=True)  # Slack team_id
    github_repo: Mapped[str | None] = mapped_column(String(200), nullable=True)
    sla_minutes: Mapped[int] = mapped_column(Integer, default=60)
    auto_detect_channels: Mapped[str] = mapped_column(Text, default="")  # comma-separated channel ids

    def auto_channels(self) -> set[str]:
        return {c.strip() for c in (self.auto_detect_channels or "").split(",") if c.strip()}


class Ticket(Base):
    __tablename__ = "tickets"
    __table_args__ = (
        UniqueConstraint("workspace_id", "channel_id", "thread_ts", name="uq_ticket_thread"),
        Index("ix_ticket_ws_status", "workspace_id", "status"),
        Index("ix_ticket_gh", "github_issue_number"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), index=True)
    channel_id: Mapped[str] = mapped_column(String(32))
    thread_ts: Mapped[str | None] = mapped_column(String(32), nullable=True)
    author_id: Mapped[str] = mapped_column(String(32))
    title: Mapped[str] = mapped_column(String(200))
    body: Mapped[str] = mapped_column(Text)
    summary: Mapped[str] = mapped_column(Text, default="")
    category: Mapped[str] = mapped_column(String(32), default="other")
    priority: Mapped[str] = mapped_column(String(16), default="medium")
    status: Mapped[str] = mapped_column(String(16), default="open")  # open | in_progress | closed
    assignee: Mapped[str | None] = mapped_column(String(100), nullable=True)
    github_issue_number: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime)
    first_response_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_sla_alert_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class ProcessedEvent(Base):
    """Idempotency table: Slack and GitHub both redeliver events."""

    __tablename__ = "processed_events"

    source: Mapped[str] = mapped_column(String(64), primary_key=True)  # e.g. "slack:T123" or "github"
    event_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    received_at: Mapped[datetime] = mapped_column(DateTime)


class TicketEvent(Base):
    """Append-only audit trail."""

    __tablename__ = "ticket_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ticket_id: Mapped[int] = mapped_column(ForeignKey("tickets.id"), index=True)
    workspace_id: Mapped[str] = mapped_column(String(32))
    type: Mapped[str] = mapped_column(String(48))
    detail: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime)


class Job(Base):
    """Transactional outbox: side effects (Slack/GitHub calls) are retried with backoff."""

    __tablename__ = "jobs"
    __table_args__ = (Index("ix_jobs_due", "status", "next_run_at"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    kind: Mapped[str] = mapped_column(String(48))
    payload: Mapped[dict] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(12), default="pending")  # pending | done | dead
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    next_run_at: Mapped[datetime] = mapped_column(DateTime)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime)
