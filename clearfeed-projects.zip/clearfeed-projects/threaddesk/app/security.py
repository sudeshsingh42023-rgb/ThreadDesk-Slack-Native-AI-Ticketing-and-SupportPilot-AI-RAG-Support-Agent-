import hashlib
import hmac
import time


def verify_slack_signature(
    secret: str,
    timestamp: str | None,
    body: bytes,
    signature: str | None,
    tolerance_s: int = 300,
    now: float | None = None,
) -> bool:
    """Slack v0 signing: HMAC-SHA256 over 'v0:<ts>:<body>', with a replay window."""
    try:
        ts = int(timestamp or "")
    except ValueError:
        return False
    if abs((now if now is not None else time.time()) - ts) > tolerance_s:
        return False
    base = f"v0:{timestamp}:".encode() + body
    expected = "v0=" + hmac.new(secret.encode(), base, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature or "")


def verify_github_signature(secret: str, body: bytes, signature: str | None) -> bool:
    expected = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature or "")
