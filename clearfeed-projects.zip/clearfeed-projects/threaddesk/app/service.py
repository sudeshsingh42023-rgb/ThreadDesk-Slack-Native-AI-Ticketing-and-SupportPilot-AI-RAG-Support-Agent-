"""Ticket business logic. No HTTP, no network: side effects are written to the job outbox."""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta
from typing import Callable

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .models import Job, ProcessedEvent, Ticket, TicketEvent, Workspace
from .triage import Triager

Clock = Callable[[], datetime]
MARKER = "[via ThreadDesk]"  # present on every comment we mirror, so webhooks for our own writes are ignored


def enqueue(session: Session, kind: str, payload: dict, now: datetime) -> None:
    session.add(Job(kind=kind, payload=payload, status="pending", attempts=0, next_run_at=now, created_at=now))


def mark_processed(session: Session, source: str, event_id: str, now: datetime) -> bool:
    """Returns True the first time an event is seen, False for redeliveries."""
    if session.get(ProcessedEvent, (source, event_id)) is not None:
        return False
    try:
        with session.begin_nested():
            session.add(ProcessedEvent(source=source, event_id=event_id, received_at=now))
        return True
    except IntegrityError:  # concurrent delivery of the same event
        return False


def audit(session: Session, ticket: Ticket, type_: str, detail: str, now: datetime) -> None:
    session.add(TicketEvent(ticket_id=ticket.id, workspace_id=ticket.workspace_id, type=type_, detail=detail, created_at=now))


class TicketService:
    def __init__(self, triager: Triager, clock: Clock, default_repo: str = "", default_sla_minutes: int = 60):
        self.triager, self.clock = triager, clock
        self.default_repo, self.default_sla = default_repo, default_sla_minutes

    # ---- tenants -----------------------------------------------------------------------------------------
    def ensure_workspace(self, session: Session, workspace_id: str) -> Workspace:
        ws = session.get(Workspace, workspace_id)
        if ws is None:
            ws = Workspace(
                id=workspace_id,
                github_repo=self.default_repo or None,
                sla_minutes=self.default_sla,
                auto_detect_channels="",
            )
            session.add(ws)
            session.flush()
        return ws

    def get_ticket(self, session: Session, workspace_id: str, ticket_id: int) -> Ticket | None:
        """Every lookup is scoped by workspace_id: one tenant can never read another's tickets."""
        return session.scalars(
            select(Ticket).where(Ticket.id == ticket_id, Ticket.workspace_id == workspace_id)
        ).first()

    def find_by_thread(self, session: Session, workspace_id: str, channel_id: str, thread_ts: str) -> Ticket | None:
        return session.scalars(
            select(Ticket).where(
                Ticket.workspace_id == workspace_id,
                Ticket.channel_id == channel_id,
                Ticket.thread_ts == thread_ts,
            )
        ).first()

    # ---- commands ----------------------------------------------------------------------------------------
    def create_ticket(
        self,
        session: Session,
        workspace_id: str,
        channel_id: str,
        author_id: str,
        text: str,
        thread_ts: str | None = None,
        announce: bool = True,
    ) -> tuple[Ticket, bool]:
        """Returns (ticket, created). Creating twice for the same Slack thread returns the existing ticket."""
        ws = self.ensure_workspace(session, workspace_id)
        if thread_ts:
            existing = self.find_by_thread(session, workspace_id, channel_id, thread_ts)
            if existing:
                return existing, False

        now = self.clock()
        result = self.triager.triage(text)
        first_line = next((ln.strip() for ln in text.splitlines() if ln.strip()), "")
        title = first_line[:80] or "(no text)"
        ticket = Ticket(
            workspace_id=workspace_id,
            channel_id=channel_id,
            thread_ts=thread_ts,
            author_id=author_id,
            title=title,
            body=text,
            summary=result.summary,
            category=result.category,
            priority=result.priority,
            status="open",
            created_at=now,
        )
        session.add(ticket)
        session.flush()
        audit(session, ticket, "created", f"{result.category}/{result.priority}", now)

        if ws.github_repo:
            enqueue(session, "github.create_issue", {"ticket_id": ticket.id}, now)
        if announce:
            enqueue(
                session,
                "slack.post",
                {
                    "channel": channel_id,
                    "thread_ts": thread_ts,
                    "text": f"🎫 Ticket #{ticket.id} created · {result.category} · priority {result.priority}",
                },
                now,
            )
        return ticket, True

    def close_ticket(self, session: Session, ticket: Ticket, source: str) -> bool:
        """Idempotent: closing a closed ticket is a no-op. `source` is 'slack' or 'github'."""
        if ticket.status == "closed":
            return False
        now = self.clock()
        ticket.status, ticket.closed_at = "closed", now
        audit(session, ticket, "closed", source, now)
        ws = session.get(Workspace, ticket.workspace_id)
        if source != "github" and ticket.github_issue_number and ws and ws.github_repo:
            enqueue(session, "github.set_state", {"ticket_id": ticket.id, "state": "closed"}, now)
        who = "Linked GitHub issue was closed" if source == "github" else "Ticket closed"
        enqueue(
            session,
            "slack.post",
            {"channel": ticket.channel_id, "thread_ts": ticket.thread_ts, "text": f"✅ {who} (ticket #{ticket.id})"},
            now,
        )
        return True

    def reopen_ticket(self, session: Session, ticket: Ticket, source: str) -> bool:
        if ticket.status != "closed":
            return False
        now = self.clock()
        ticket.status, ticket.closed_at = "open", None
        audit(session, ticket, "reopened", source, now)
        ws = session.get(Workspace, ticket.workspace_id)
        if source != "github" and ticket.github_issue_number and ws and ws.github_repo:
            enqueue(session, "github.set_state", {"ticket_id": ticket.id, "state": "open"}, now)
        enqueue(
            session,
            "slack.post",
            {"channel": ticket.channel_id, "thread_ts": ticket.thread_ts, "text": f"🔁 Ticket #{ticket.id} reopened"},
            now,
        )
        return True

    def handle_reply(self, session: Session, workspace_id: str, channel_id: str, thread_ts: str, user_id: str, text: str) -> None:
        ticket = self.find_by_thread(session, workspace_id, channel_id, thread_ts)
        if ticket is None or ticket.status == "closed":
            return
        now = self.clock()
        if user_id != ticket.author_id and ticket.first_response_at is None:
            ticket.first_response_at = now
            audit(session, ticket, "first_response", user_id, now)
        if ticket.status == "open" and user_id != ticket.author_id:
            ticket.status = "in_progress"
        if ticket.github_issue_number:
            enqueue(
                session,
                "github.comment",
                {"ticket_id": ticket.id, "body": f"**<@{user_id}>** (Slack): {text}\n\n{MARKER}"},
                now,
            )

    # ---- GitHub -> Slack ---------------------------------------------------------------------------------
    def apply_github_event(self, session: Session, event: str, payload: dict, bot_login: str = "") -> str:
        repo = (payload.get("repository") or {}).get("full_name")
        issue = payload.get("issue") or {}
        number = issue.get("number")
        if not repo or number is None:
            return "ignored:no-issue"
        sender = (payload.get("sender") or {}).get("login", "")
        if bot_login and sender == bot_login:
            return "ignored:own-write"

        ticket = session.scalars(
            select(Ticket)
            .join(Workspace, Workspace.id == Ticket.workspace_id)
            .where(Workspace.github_repo == repo, Ticket.github_issue_number == number)
        ).first()
        if ticket is None:
            return "ignored:unlinked"

        action = payload.get("action")
        if event == "issues" and action == "closed":
            return "closed" if self.close_ticket(session, ticket, "github") else "noop:already-closed"
        if event == "issues" and action == "reopened":
            return "reopened" if self.reopen_ticket(session, ticket, "github") else "noop:already-open"
        if event == "issues" and action == "assigned":
            login = (payload.get("assignee") or {}).get("login")
            if login and ticket.assignee != login:
                ticket.assignee = login
                audit(session, ticket, "assigned", login, self.clock())
                return "assigned"
            return "noop:same-assignee"
        if event == "issue_comment" and action == "created":
            body = (payload.get("comment") or {}).get("body", "")
            if MARKER in body:
                return "ignored:own-write"
            enqueue(
                session,
                "slack.post",
                {
                    "channel": ticket.channel_id,
                    "thread_ts": ticket.thread_ts,
                    "text": f"💬 *{sender}* on GitHub: {body[:500]}",
                },
                self.clock(),
            )
            return "commented"
        return "ignored:unhandled"

    # ---- SLA ---------------------------------------------------------------------------------------------
    def run_sla_check(self, session: Session) -> int:
        """Remind once per ticket when nobody has replied within the workspace SLA."""
        now, alerted = self.clock(), 0
        for ws in session.scalars(select(Workspace)):
            cutoff = now - timedelta(minutes=ws.sla_minutes)
            breached = session.scalars(
                select(Ticket).where(
                    Ticket.workspace_id == ws.id,
                    Ticket.status == "open",
                    Ticket.first_response_at.is_(None),
                    Ticket.last_sla_alert_at.is_(None),
                    Ticket.created_at <= cutoff,
                )
            )
            for t in breached:
                t.last_sla_alert_at = now
                audit(session, t, "sla_breach", f"{ws.sla_minutes}m", now)
                enqueue(
                    session,
                    "slack.post",
                    {
                        "channel": t.channel_id,
                        "thread_ts": t.thread_ts,
                        "text": f"⏰ Ticket #{t.id} has had no response for {ws.sla_minutes} minutes.",
                    },
                    now,
                )
                alerted += 1
        return alerted


# ---- metrics ---------------------------------------------------------------------------------------------
def channel_metrics(session: Session, workspace_id: str) -> dict[str, dict]:
    rows = session.scalars(select(Ticket).where(Ticket.workspace_id == workspace_id)).all()
    grouped: dict[str, list[Ticket]] = defaultdict(list)
    for t in rows:
        grouped[t.channel_id].append(t)

    def avg(values: list[float]) -> float | None:
        return round(sum(values) / len(values), 1) if values else None

    out: dict[str, dict] = {}
    for channel, tickets in grouped.items():
        out[channel] = {
            "total": len(tickets),
            "open": sum(t.status != "closed" for t in tickets),
            "closed": sum(t.status == "closed" for t in tickets),
            "avg_first_response_s": avg(
                [(t.first_response_at - t.created_at).total_seconds() for t in tickets if t.first_response_at]
            ),
            "avg_closure_s": avg([(t.closed_at - t.created_at).total_seconds() for t in tickets if t.closed_at]),
            "sla_breaches": sum(t.last_sla_alert_at is not None for t in tickets),
        }
    return out


def home_blocks(metrics: dict[str, dict]) -> list[dict]:
    blocks: list[dict] = [{"type": "header", "text": {"type": "plain_text", "text": "ThreadDesk dashboard"}}]
    if not metrics:
        blocks.append({"type": "section", "text": {"type": "mrkdwn", "text": "No tickets yet."}})
    for channel, m in sorted(metrics.items()):
        fr = f"{m['avg_first_response_s']}s" if m["avg_first_response_s"] is not None else "n/a"
        blocks.append(
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*<#{channel}>*  open: {m['open']} · closed: {m['closed']} · "
                    f"avg first response: {fr} · SLA breaches: {m['sla_breaches']}",
                },
            }
        )
    return blocks
