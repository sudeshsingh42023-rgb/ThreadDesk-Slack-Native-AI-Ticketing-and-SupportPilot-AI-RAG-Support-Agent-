"""Outbox worker: executes Slack/GitHub side effects with exponential backoff.

Delivery is at-least-once. Handlers are written to be idempotent where possible (e.g. create_issue skips if the
ticket already has an issue number). The one remaining window is a crash between GitHub accepting an issue and
our commit; see README "Known limitations".
"""
from __future__ import annotations

import logging
import threading
from datetime import timedelta

from sqlalchemy import select

from .clients import GitHubClient, SlackClient
from .db import session_scope
from .models import Job, Ticket, Workspace
from .service import Clock, TicketService, enqueue

log = logging.getLogger("threaddesk.worker")


class Worker:
    def __init__(
        self,
        session_factory,
        slack: SlackClient,
        github: GitHubClient,
        service: TicketService,
        clock: Clock,
        max_attempts: int = 5,
        backoff_base_s: int = 5,
    ):
        self.sf, self.slack, self.github, self.service, self.clock = session_factory, slack, github, service, clock
        self.max_attempts, self.backoff_base_s = max_attempts, backoff_base_s
        self._stop = threading.Event()

    # ---- job handlers ------------------------------------------------------------------------------------
    def _handle(self, session, job: Job) -> None:
        p = job.payload
        if job.kind == "slack.post":
            self.slack.post_message(p["channel"], p["text"], p.get("thread_ts"))
            return

        ticket = session.get(Ticket, p["ticket_id"])
        ws = session.get(Workspace, ticket.workspace_id) if ticket else None
        if ticket is None or ws is None or not ws.github_repo:
            return  # nothing to do; drop silently

        if job.kind == "github.create_issue":
            if ticket.github_issue_number:
                return  # already created (retry after partial failure)
            body = f"{ticket.body}\n\n---\nSlack channel `{ticket.channel_id}` · ThreadDesk ticket #{ticket.id}"
            number = self.github.create_issue(
                ws.github_repo, ticket.title, body, [ticket.category, f"priority:{ticket.priority}"]
            )
            ticket.github_issue_number = number
            enqueue(
                session,
                "slack.post",
                {
                    "channel": ticket.channel_id,
                    "thread_ts": ticket.thread_ts,
                    "text": f"🔗 Linked GitHub issue https://github.com/{ws.github_repo}/issues/{number}",
                },
                self.clock(),
            )
        elif job.kind == "github.set_state" and ticket.github_issue_number:
            self.github.set_state(ws.github_repo, ticket.github_issue_number, p["state"])
        elif job.kind == "github.comment" and ticket.github_issue_number:
            self.github.comment(ws.github_repo, ticket.github_issue_number, p["body"])
        else:
            log.warning("unknown or inapplicable job kind %s", job.kind)

    # ---- loop --------------------------------------------------------------------------------------------
    def run_once(self, limit: int = 50) -> int:
        """Runs the SLA check, then every due job. Returns the number of jobs completed."""
        with session_scope(self.sf) as s:
            self.service.run_sla_check(s)

        done = 0
        with session_scope(self.sf) as s:
            ids = s.scalars(
                select(Job.id)
                .where(Job.status == "pending", Job.next_run_at <= self.clock())
                .order_by(Job.id)
                .limit(limit)
                .with_for_update(skip_locked=True)
            ).all()

        for job_id in ids:
            with session_scope(self.sf) as s:
                job = s.get(Job, job_id)
                if job is None or job.status != "pending":
                    continue
                try:
                    self._handle(s, job)
                    job.status = "done"
                    done += 1
                except Exception as exc:  # noqa: BLE001 - any failure schedules a retry
                    job.attempts += 1
                    job.last_error = f"{type(exc).__name__}: {exc}"[:500]
                    if job.attempts >= self.max_attempts:
                        job.status = "dead"
                        log.error("job %s dead after %s attempts: %s", job.id, job.attempts, job.last_error)
                    else:
                        delay = self.backoff_base_s * (2 ** (job.attempts - 1))
                        job.next_run_at = self.clock() + timedelta(seconds=delay)
        return done

    def run_forever(self, interval_s: float) -> None:
        while not self._stop.is_set():
            try:
                self.run_once()
            except Exception:  # noqa: BLE001
                log.exception("worker tick failed")
            self._stop.wait(interval_s)

    def stop(self) -> None:
        self._stop.set()
