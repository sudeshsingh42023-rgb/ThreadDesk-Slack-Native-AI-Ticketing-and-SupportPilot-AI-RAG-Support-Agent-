import hashlib
import hmac
import json
import time
from datetime import datetime, timedelta
from urllib.parse import urlencode

import pytest
from fastapi.testclient import TestClient

from app.clients import FakeGitHubClient, FakeSlackClient
from app.config import Settings
from app.main import create_app
from app.triage import HeuristicTriager

SIGNING = "test-signing"
GH_SECRET = "test-gh"
REPO = "acme/support"


class FakeClock:
    def __init__(self):
        self.now = datetime(2026, 10, 7, 9, 0, 0)

    def __call__(self):
        return self.now

    def advance(self, **kw):
        self.now += timedelta(**kw)


@pytest.fixture
def env(tmp_path):
    clock, slack, gh = FakeClock(), FakeSlackClient(), FakeGitHubClient()
    settings = Settings(
        database_url=f"sqlite:///{tmp_path}/t.db",
        slack_signing_secret=SIGNING,
        github_webhook_secret=GH_SECRET,
        default_github_repo=REPO,
        default_sla_minutes=60,
        worker_enabled=False,
        job_backoff_base_s=5,
        job_max_attempts=3,
        api_key="k",
    )
    app = create_app(settings, slack=slack, github=gh, triager=HeuristicTriager(), clock=clock)
    with TestClient(app) as client:
        yield type("Env", (), {"client": client, "app": app, "clock": clock, "slack": slack, "gh": gh, "worker": app.state.worker})


def slack_headers(body: bytes, secret=SIGNING, ts=None):
    ts = str(ts if ts is not None else int(time.time()))
    sig = "v0=" + hmac.new(secret.encode(), f"v0:{ts}:".encode() + body, hashlib.sha256).hexdigest()
    return {"X-Slack-Request-Timestamp": ts, "X-Slack-Signature": sig}


def post_event(env, event, team="T1", event_id="Ev1"):
    body = json.dumps({"type": "event_callback", "team_id": team, "event_id": event_id, "event": event}).encode()
    return env.client.post("/slack/events", content=body, headers={**slack_headers(body), "Content-Type": "application/json"})


def post_command(env, text, team="T1", channel="C1", user="U1"):
    body = urlencode({"team_id": team, "channel_id": channel, "user_id": user, "text": text}).encode()
    return env.client.post("/slack/commands", content=body, headers={**slack_headers(body), "Content-Type": "application/x-www-form-urlencoded"})


def post_shortcut(env, text, ts="100.1", team="T1", channel="C1", user="U1"):
    payload = {"type": "message_action", "callback_id": "create_ticket", "team": {"id": team}, "channel": {"id": channel},
               "user": {"id": user}, "message": {"text": text, "ts": ts, "user": user}}
    body = urlencode({"payload": json.dumps(payload)}).encode()
    return env.client.post("/slack/interactions", content=body, headers={**slack_headers(body), "Content-Type": "application/x-www-form-urlencoded"})


def post_github(env, event, payload, delivery="d1", secret=GH_SECRET):
    body = json.dumps(payload).encode()
    sig = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return env.client.post("/github/webhook", content=body, headers={
        "X-GitHub-Event": event, "X-GitHub-Delivery": delivery, "X-Hub-Signature-256": sig, "Content-Type": "application/json"})


def gh_payload(action, number, login="alice", **extra):
    return {"action": action, "repository": {"full_name": REPO}, "issue": {"number": number}, "sender": {"login": login}, **extra}
