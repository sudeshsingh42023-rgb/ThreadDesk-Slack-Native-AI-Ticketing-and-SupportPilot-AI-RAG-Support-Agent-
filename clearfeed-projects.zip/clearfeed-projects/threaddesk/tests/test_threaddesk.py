import json

from sqlalchemy import select

from app.db import session_scope
from app.models import Job, Ticket, Workspace
from tests.conftest import (gh_payload, post_command, post_event, post_github, post_shortcut, slack_headers, REPO)


# ---- security ---------------------------------------------------------------------------------------------
def test_rejects_bad_slack_signature(env):
    body = b'{"type":"url_verification","challenge":"x"}'
    r = env.client.post("/slack/events", content=body, headers=slack_headers(body, secret="wrong"))
    assert r.status_code == 401


def test_rejects_replayed_old_timestamp(env):
    body = b'{"type":"url_verification","challenge":"x"}'
    r = env.client.post("/slack/events", content=body, headers=slack_headers(body, ts=1_000))
    assert r.status_code == 401


def test_url_verification_handshake(env):
    body = b'{"type":"url_verification","challenge":"abc"}'
    r = env.client.post("/slack/events", content=body, headers={**slack_headers(body), "Content-Type": "application/json"})
    assert r.json() == {"challenge": "abc"}


def test_rejects_bad_github_signature(env):
    assert post_github(env, "issues", gh_payload("closed", 1), secret="nope").status_code == 401


# ---- ticket creation + triage ----------------------------------------------------------------------------
def test_slash_command_creates_ticket_and_github_issue(env):
    assert post_command(env, "Login page crashes with a 500 error").json()["text"].startswith("Created ticket #1")
    env.worker.run_once()  # creates the issue and enqueues the "linked" Slack message
    env.worker.run_once()  # delivers it
    assert env.gh.issues[(REPO, 1)]["labels"] == ["incident", "priority:urgent"]
    texts = [m["text"] for m in env.slack.messages]
    assert any("Ticket #1 created" in t for t in texts) and any("Linked GitHub issue" in t for t in texts)


def test_message_shortcut_is_idempotent_per_thread(env):
    assert post_shortcut(env, "How do I reset my API key?").json()["created"] is True
    assert post_shortcut(env, "How do I reset my API key?").json()["created"] is False
    with session_scope(env.app.state.sf) as s:
        assert len(s.scalars(select(Ticket)).all()) == 1


def test_auto_detect_only_in_configured_channels(env):
    post_command(env, "seed workspace")  # creates workspace row T1
    with session_scope(env.app.state.sf) as s:
        s.get(Workspace, "T1").auto_detect_channels = "CAUTO"
    post_event(env, {"type": "message", "channel": "COTHER", "user": "U9", "text": "Is there a way to export data?", "ts": "1.1"}, event_id="E1")
    post_event(env, {"type": "message", "channel": "CAUTO", "user": "U9", "text": "Is there a way to export data?", "ts": "2.2"}, event_id="E2")
    post_event(env, {"type": "message", "channel": "CAUTO", "user": "U9", "text": "thanks everyone!", "ts": "3.3"}, event_id="E3")
    with session_scope(env.app.state.sf) as s:
        tickets = s.scalars(select(Ticket).where(Ticket.channel_id.in_(["CAUTO", "COTHER"]))).all()
        assert [(t.channel_id, t.category) for t in tickets] == [("CAUTO", "question")]


def test_bot_messages_are_ignored(env):
    post_command(env, "seed")
    with session_scope(env.app.state.sf) as s:
        s.get(Workspace, "T1").auto_detect_channels = "CAUTO"
    post_event(env, {"type": "message", "channel": "CAUTO", "bot_id": "B1", "text": "Is anything broken?", "ts": "9.9"}, event_id="EB")
    with session_scope(env.app.state.sf) as s:
        assert len(s.scalars(select(Ticket).where(Ticket.channel_id == "CAUTO")).all()) == 0


# ---- idempotency ------------------------------------------------------------------------------------------
def test_duplicate_slack_event_processed_once(env):
    post_command(env, "seed")
    with session_scope(env.app.state.sf) as s:
        s.get(Workspace, "T1").auto_detect_channels = "CAUTO"
    ev = {"type": "message", "channel": "CAUTO", "user": "U9", "text": "app crashes on start", "ts": "5.5"}
    assert post_event(env, ev, event_id="EDUP").json().get("duplicate") is None
    assert post_event(env, ev, event_id="EDUP").json()["duplicate"] is True


def test_duplicate_github_delivery_processed_once(env):
    post_command(env, "Something is broken")
    env.worker.run_once()
    assert post_github(env, "issues", gh_payload("closed", 1), delivery="D1").json()["result"] == "closed"
    assert post_github(env, "issues", gh_payload("closed", 1), delivery="D1").json()["result"] == "duplicate"


# ---- two-way sync + loop prevention ----------------------------------------------------------------------
def test_close_in_slack_closes_github_and_echo_does_not_loop(env):
    post_command(env, "Something is broken")
    env.worker.run_once()
    assert post_command(env, "close 1").json()["text"] == "Closed."
    env.worker.run_once()
    assert env.gh.issues[(REPO, 1)]["state"] == "closed"
    before = len(env.slack.messages)
    # GitHub now echoes back an "issues closed" webhook for our own write: must be a no-op
    assert post_github(env, "issues", gh_payload("closed", 1), delivery="D2").json()["result"] == "noop:already-closed"
    env.worker.run_once()
    assert len(env.slack.messages) == before  # no second "closed" message


def test_close_on_github_updates_ticket_and_posts_once(env):
    post_command(env, "Something is broken")
    env.worker.run_once()
    assert post_github(env, "issues", gh_payload("closed", 1), delivery="D3").json()["result"] == "closed"
    env.worker.run_once()
    assert sum("GitHub issue was closed" in m["text"] for m in env.slack.messages) == 1
    assert not [j for j in _jobs(env) if j.kind == "github.set_state"]  # did not echo back to GitHub


def test_slack_reply_mirrors_to_github_without_looping(env):
    post_shortcut(env, "Export button crashes", ts="50.5", user="U1")
    env.worker.run_once()
    post_event(env, {"type": "message", "channel": "C1", "user": "U2", "text": "Looking into it", "ts": "51.1", "thread_ts": "50.5"}, event_id="ER1")
    env.worker.run_once()
    assert "Looking into it" in env.gh.comments[0]["body"]
    # webhook for the comment we just wrote carries our marker -> ignored
    echo = gh_payload("created", 1, comment={"body": env.gh.comments[0]["body"]})
    assert post_github(env, "issue_comment", echo, delivery="D4").json()["result"] == "ignored:own-write"
    # a human GitHub comment is relayed to Slack
    human = gh_payload("created", 1, login="bob", comment={"body": "Reproduced on v2.3"})
    assert post_github(env, "issue_comment", human, delivery="D5").json()["result"] == "commented"
    env.worker.run_once()
    assert any("Reproduced on v2.3" in m["text"] for m in env.slack.messages)


def test_github_assignment_updates_ticket(env):
    post_command(env, "Something is broken")
    env.worker.run_once()
    r = post_github(env, "issues", gh_payload("assigned", 1, assignee={"login": "carol"}), delivery="D6")
    assert r.json()["result"] == "assigned"
    assert env.client.get("/api/tickets/1", params={"workspace_id": "T1"}, headers={"X-API-Key": "k"}).json()["assignee"] == "carol"


def test_unlinked_issue_is_ignored(env):
    assert post_github(env, "issues", gh_payload("closed", 999), delivery="D7").json()["result"] == "ignored:unlinked"


# ---- reliability: retries with backoff --------------------------------------------------------------------
def test_failed_job_retries_with_exponential_backoff_then_succeeds(env):
    env.gh.fail_next = 2
    post_command(env, "Something is broken")
    env.worker.run_once()                       # attempt 1 fails
    assert (REPO, 1) not in env.gh.issues
    env.clock.advance(seconds=4); env.worker.run_once()    # backoff is 5s: not due yet
    assert env.gh.fail_next == 1
    env.clock.advance(seconds=2); env.worker.run_once()    # attempt 2 fails (next delay 10s)
    assert env.gh.fail_next == 0
    env.clock.advance(seconds=9); env.worker.run_once()
    assert (REPO, 1) not in env.gh.issues
    env.clock.advance(seconds=2); env.worker.run_once()    # attempt 3 succeeds
    assert (REPO, 1) in env.gh.issues


def test_job_marked_dead_after_max_attempts(env):
    env.gh.fail_next = 99
    post_command(env, "Something is broken")
    for _ in range(5):
        env.worker.run_once()
        env.clock.advance(minutes=5)
    dead = [j for j in _jobs(env) if j.status == "dead"]
    assert len(dead) == 1 and "simulated github outage" in dead[0].last_error


# ---- SLA + metrics ----------------------------------------------------------------------------------------
def test_sla_alert_fires_once_and_first_response_stops_it(env):
    post_shortcut(env, "Cannot export, error shown", ts="70.1", user="U1")
    post_shortcut(env, "Another error appears", ts="71.1", user="U1")
    post_event(env, {"type": "message", "channel": "C1", "user": "U2", "text": "on it", "ts": "72.2", "thread_ts": "71.1"}, event_id="ES1")
    env.clock.advance(minutes=61)
    env.worker.run_once(); env.worker.run_once()
    alerts = [m for m in env.slack.messages if "no response" in m["text"]]
    assert len(alerts) == 1 and alerts[0]["thread_ts"] == "70.1"


def test_metrics_per_channel(env):
    post_shortcut(env, "Cannot export, error shown", ts="80.1", user="U1")
    env.clock.advance(seconds=120)
    post_event(env, {"type": "message", "channel": "C1", "user": "U2", "text": "checking", "ts": "81.1", "thread_ts": "80.1"}, event_id="EM1")
    env.clock.advance(seconds=60)
    post_command(env, "close 1")
    m = env.client.get("/api/workspaces/T1/metrics", headers={"X-API-Key": "k"}).json()["C1"]
    assert (m["total"], m["closed"], m["avg_first_response_s"], m["avg_closure_s"]) == (1, 1, 120.0, 180.0)


def test_home_tab_published(env):
    post_shortcut(env, "Cannot export, error shown", ts="90.1")
    post_event(env, {"type": "app_home_opened", "user": "U1"}, event_id="EH1")
    assert env.slack.home_views and "ThreadDesk dashboard" in json.dumps(env.slack.home_views[0]["blocks"])


# ---- tenant isolation -------------------------------------------------------------------------------------
def test_tenant_isolation(env):
    post_command(env, "Tenant one has a bug", team="T1")
    post_command(env, "Tenant two has a bug", team="T2")
    h = {"X-API-Key": "k"}
    assert env.client.get("/api/tickets/1", params={"workspace_id": "T1"}, headers=h).status_code == 200
    assert env.client.get("/api/tickets/1", params={"workspace_id": "T2"}, headers=h).status_code == 404
    assert post_command(env, "close 1", team="T2").json()["text"] == "Ticket not found."
    assert set(env.client.get("/api/workspaces/T2/metrics", headers=h).json()) == {"C1"}
    assert env.client.get("/api/workspaces/T2/metrics", headers=h).json()["C1"]["total"] == 1


def test_api_requires_key(env):
    assert env.client.get("/api/tickets/1", params={"workspace_id": "T1"}).status_code == 401


def _jobs(env):
    with session_scope(env.app.state.sf) as s:
        return s.scalars(select(Job)).all()


def test_title_is_first_line_only(env):
    r = env.client.post("/api/tickets", headers={"X-API-Key": "k"}, json={
        "workspace_id": "T1", "channel_id": "C1", "author_id": "U1", "title": "Export crashes", "body": "Requested via SupportPilot"})
    assert r.status_code == 200
    env.worker.run_once()
    assert env.gh.issues[(REPO, 1)]["title"] == "Export crashes"
